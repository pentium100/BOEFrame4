<!--
var countMenus = 0;
var firstMenu = 0;
var ExtraSpace = 10;
var previousCountMenu = 0;

var gcountMenusItem4Width = 0;

function Menu(label) 
{
    this.type="Menu";
    this.menuBorder=2;
	this.menuItemBorder=0;
	this.menuItemHeight=20;
	this.childMenuIcon="images/menu_arrows.gif";
    this.childMenuIconHilite="images/menu_arrows.gif";
	this.use4DrillDoc=true; 

	this.MenuItemPicture=new Array();
    this.items=new Array();
    this.actions=new Array();
    this.colors=new Array();
    this.mouseovers=new Array();
    this.mouseouts=new Array();
    this.childMenus=new Array();
	this.ExtraInfo4Items=new Array();
	this.tooltips=new Array();

    this.addMenuItem			=		addMenuItem;
    this.addMenuSeparator		=		addMenuSeparator;
    this.writeMenus				=		writeMenus;
    this.showMenu				=		showMenu;
    this.onMenuItemOver			=		onMenuItemOver;
    this.onMenuItemOut			=		onMenuItemOut;
    this.onMenuItemDown			=		onMenuItemDown;
    this.onMenuItemAction		=		onMenuItemAction;
    this.hideMenu				=		hideMenu;
    this.hideChildMenu			=		hideChildMenu;
    this.mouseTracker			=		mouseTracker;
    this.setMouseTracker		=		setMouseTracker;
	this.Action					=		Action;
	
    if (!window.menus) 
		window.menus = new Array();
    this.label = label || "menuLabel" + window.menus.length;
    window.menus[this.label] = this;
    window.menus[window.menus.length] = this;
    if (!window.activeMenus) 
		window.activeMenus = new Array();
    if (!window.menuContainers) 
		window.menuContainers = new Array();
	this.setMouseTracker();
	
}

function addMenuItem(label, action, color, mouseover, mouseout, extrainfo, tooltip, picture) 
{
	var o=this;o.items[this.items.length] = label;o.actions[this.actions.length] = action;o.colors[this.colors.length] = color;o.mouseovers[this.mouseovers.length] = mouseover;o.mouseouts[this.mouseouts.length] = mouseout;o.ExtraInfo4Items[this.ExtraInfo4Items.length] = extrainfo;o.tooltips[this.tooltips.length] = tooltip;o.MenuItemPicture[this.MenuItemPicture.length] = picture;
}

function Action(valid, DrillAction, BID, PBID, DimFrom, HierTo, DimTo, DrillFilter, SortValue, ivAction)
{
	var o=this;o.valid	= valid;o.DrillAction = DrillAction;o.BID = BID;o.PBID = PBID;o.DimFrom = DimFrom;o.HierTo = HierTo;o.DimTo = DimTo;o.DrillFilter = DrillFilter;o.SortValue = SortValue;o.IVAction = ivAction;
}

function addMenuSeparator() 
{
    this.items[this.items.length] = "separator";
    this.actions[this.actions.length] = "";
	this.ExtraInfo4Items[this.ExtraInfo4Items.length] = "";
    this.menuItemBorder = 1;
}
////////////////////////////////////////////////////////////////////////////////////////////////

function writeMenus(container) 
{
	if (!container) 
	{
		if (!document.getElementById("menuContainer"))
		{
			var objContainer = document.createElement("SPAN");
			objContainer.id = "menuContainer";
			document.body.appendChild(objContainer);
		}
		container=document.getElementById("menuContainer");
	}
    if (!container && !window.delayWriteMenus) 
	{
        window.delayWriteMenus = this.writeMenus;
        window.menuContainerBgColor = this.menuContainerBgColor;
        setTimeout('delayWriteMenus()', 3000);
        return;
    }
	
	container.isContainer = "menuContainer" + menuContainers.length;
    menuContainers[menuContainers.length] = container;
    container.menus = new Array();

    for (var i=0; i < window.menus.length; i++) 
		container.menus[i] = window.menus[i];

    window.menus.length = 0;
    var countItems = 0;
    var top = 0;
    var content = '';
    var proto;
	countMenus = 0;
	if(bw.saf)	// this code is used only for Safari browser on MAC (Destroy all DIV element append to menuContainer)
	{
		for (var im = 0; im < previousCountMenu; im++)
		{
			var menuLay = document.getElementById("menuLayer"+ im);
			if(menuLay)
				removeMenu(container, menuLay);
		}
	}

	firstMenu = countMenus; // initialize index of first menu
    for (var i = 0; i < container.menus.length; i++, countMenus++) 
	{
		var objMenuLayer, objMenuLite, objMenuFg, objMenuItem, objMenuItemText, objFocusMenuItem;
        var menu = container.menus[i];

        proto = menu.prototypeStyles || this.prototypeStyles || menu;
        
        objMenuLayer = document.createElement("DIV");objMenuLayer.id="menuLayer"+ countMenus;objMenuLayer.className="Menu";objMenuLayer.style.left="10px";objMenuLayer.style.top=(i * 100);objMenuLayer.style.visibility="hidden";
	
        objMenuLite = document.createElement("DIV");objMenuLite.id="menuLite"+ countMenus;objMenuLite.style.position="absolute";
        objMenuLite.style.left = proto.menuBorder;
        objMenuLite.style.top = proto.menuBorder;
        objMenuLite.style.visibility = "inherit";
		objMenuLite.addEventListener("mouseout", hideMenu, false);
		objMenuLite.className = "MenuLite";
        
        objMenuFg = document.createElement("DIV");
        objMenuFg.id = "menuFg" + countMenus;
        objMenuFg.style.position = "absolute";
        objMenuFg.style.left  = "1px";
        objMenuFg.style.top = "1px";
        objMenuFg.style.visibility = "inherit";
        
	for (var j=0; j<menu.items.length; j++) 
	{
            var item = menu.items[j];
            var childMenu = false;
            var defaultHeight = 20;
            var defaultIndent = 15;
            if (item.label)
			{
				item=item.label;
				childMenu=true;
			} 
		
			proto.menuItemHeight = parseInt(proto.menuItemHeight) || defaultHeight;
			proto.menuItemIndent = parseInt(proto.menuItemIndent) || defaultIndent;
	
			var skin = '';
			if(menu.actions[j]!='DISABLED')
				skin = "MenuFont ";
			else skin = "MenuFontDisabled ";
			if(menu.MenuItemPicture[j])
				skin += menu.MenuItemPicture[j];
			
			objMenuItem = document.createElement("DIV");
			objMenuItem.id = "menuItem" + countItems;
			objMenuItem.style.position = "absolute";
			objMenuItem.style.left = "0px";
			objMenuItem.style.top = (j * (proto.menuItemHeight + proto.menuBorder));
			objMenuItem.style.visibility = "inherit";
			objMenuItem.style.width = "200px";
			objMenuItem.style.height = "22px";
			objMenuItem.className="MenuFont MenuItemDefault";

			if(menu.actions[j]!='DISABLED')
			{
				objMenuItem.addEventListener("click", onMenuItemAction, false);
				objMenuItem.addEventListener("mouseover", onMenuItemOver, false);
				objMenuItem.addEventListener("mouseout", onMenuItemOut, false);
			}	        			
			objMenuItemText = document.createElement("DIV");
			objMenuItemText.id = "menuItemText"+ countItems;
			objMenuItemText.style.position = "absolute";
			objMenuItemText.style.left = "0px";
			objMenuItemText.style.top = "0px";
			objMenuItemText.className = skin;
			objMenuItemText.style.visibility = "inherit";

			var objtext=document.createTextNode(item);

			objMenuItemText.appendChild(objtext);
			objMenuItem.appendChild(objMenuItemText);
		

			if(childMenu)
			{
				var objChildMenu = document.createElement("DIV");
				objChildMenu.id = "childMenu" + countItems;
				objChildMenu.style.position = "absolute";
				objChildMenu.className = "MenuFont";
				objChildMenu.style.visibility = "inherit";
		
				var objImgMenu = document.createElement("IMG");
				objImgMenu.src = proto.childMenuIcon;

				objChildMenu.appendChild(objImgMenu);
				objMenuItem.appendChild(objChildMenu);
			}
			objMenuFg.appendChild(objMenuItem);

			countItems++;
		}
	
		objMenuLite.appendChild(objMenuFg);
		objMenuLayer.appendChild(objMenuLite);
		container.appendChild(objMenuLayer);
    }
	previousCountMenu = countMenus;
    if (!container) return;

	window.wroteMenu = true;
   
	proto = null;
    var menuCount = 0;
	var ItemWidthMax = 0;
	gcountMenusItem4Width = 0;

	for (var x=0; x < container.menus.length; x++) 
	{
		var xoffset = firstMenu + x;
		var menu = document.getElementById("menuLayer" + xoffset);
		if(menu)
		{
			container.menus[x].menuLayer = menu;
			container.menus[x].menuLayer.Menu = container.menus[x];
			container.menus[x].menuLayer.Menu.container = menu;
			proto = container.menus[x].prototypeStyles || this.prototypeStyles || container.menus[x];
			proto.menuItemWidth = parseInt(proto.menuItemWidth) || 150;
		}

		ItemWidthMax = FindMaxWidth4MenuItem(container.menus[x], menu);

        for (var i = 0; i < container.menus[x].items.length; i++) 
		{
			var l = document.getElementById("menuItem" + menuCount);
			if(!l)
				continue;
		
            l.Menu = container.menus[x];
		l.style.width = ItemWidthMax;
            proto = container.menus[x].prototypeStyles || this.prototypeStyles || container.menus[x];
         
			if(l.Menu.items[i] == "separator")
				l.style.height = 2;
			else
				l.style.height = proto.menuItemHeight;
           
            l.style.visibility = "inherit";
            l.action = container.menus[x].actions[i];

          //l.style.clip.width = proto.menuItemWidth || body.clip.width + proto.menuItemIndent;
           // l.style.clip.height = proto.menuItemHeight || l.clip.height;
            
            l.mouseover = l.Menu.mouseovers[x];
        l.mouseout  = l.Menu.mouseouts[x];
			l.ExtraInfo = container.menus[x].ExtraInfo4Items[i];
			l.tooltip = container.menus[x].tooltips[i];
			
			var objItemText = document.getElementById("menuItemText" + menuCount);
			if(objItemText)
			{
				objItemText.style.height = l.offsetHeight;
				objItemText.style.top =  (l.offsetHeight - objItemText.offsetHeight) / 2;
			}

            var childItem = document.getElementById("childMenu" + menuCount);
            if (childItem) 
			{
				l.style.height = proto.menuItemHeight;
	            if (i>0) 
					l.style.top = document.getElementById("menuItem" + eval(menuCount -1)).offsetTop + document.getElementById("menuItem" + eval(menuCount -1)).offsetHeight;

                l.childMenu = container.menus[x].items[i].menuLayer;
                childItem.style.left = l.offsetWidth -11;
                childItem.style.top = (l.offsetHeight /2) -4;
                childItem.style.clip = "rect(0px 7px 7px 3px)";
                l.Menu.childMenus[l.Menu.childMenus.length] = l.childMenu;
            }
	      menuCount++;
        }
        if(l)
			proto.menuHeight = (parseInt(l.offsetTop) + parseInt(l.offsetHeight)); 

        var lite = document.getElementById("menuLite" + xoffset);
		if(lite)
		{
			lite.style.height = proto.menuHeight+2;
			lite.style.width = ItemWidthMax;
			lite.className = "MenuLite";
		}
		var layer = document.getElementById("menuLayer"+xoffset);
		if(layer)
		{
			layer.style.height = proto.menuHeight+4;
			layer.style.width = ItemWidthMax+20;
		}

		if (menu.Menu.enableTracker) {menu.Menu.disableHide = true;setMenuTracker(menu.Menu);}
    }
    window.wroteMenu = true;
}

function onMenuItemOver(e) 
{
	l = e.currentTarget;
	l = document.getElementById(l.id);
	if(!l)
		return;

	if (l.style) 
	{
		if(l.Menu==null)
			return;

		document.onmousedown=l.Menu.onMenuItemDown;
		if(l.ExtraInfo)
		{
			switch(typeof(l.ExtraInfo))
			{
				case 'string':
					self.status = l.ExtraInfo;
				break;
				case 'object':
					switch(l.ExtraInfo[INDEX_DRILLTYPE])
					{
						case D:
							self.status = _LOC_DRILLDOWNTO + l.ExtraInfo[INDEX_DIMNAME];
						break;
						case U:
							self.status = _LOC_DRILLUPTO + l.ExtraInfo[INDEX_DIMNAME];
						break;
						case B:
							self.status = _LOC_DRILLBY + l.ExtraInfo[INDEX_DIMNAME];
						break;
					}
				break;
			}
		}
		l.className = "MenuFont MenuItemOver";
		l.Menu.hideChildMenu(l);
	}
}

function onMenuItemOut(e) 
{
	var l = e.currentTarget;
	l = document.getElementById(l.id);// SAFARI

	if(l)
	{
		l.className = "MenuFont MenuItemDefault";
		e.stopPropagation();
	}
	self.status = '';
}

function onMenuItemAction(e) 
{
	var l = e.currentTarget;
	l = document.getElementById(l.id);// SAFARI
	if(!l)	return;
	
	if(l.action)
	{
		if (ActiveMenu.Menu.use4DrillDoc)
			GenerateURL(l.action);
		else
			eval("" + l.action);
	}
}

function showMenu(menu, x, y, child) 
{
	if (!window.wroteMenu) 
		return;

	var nLastMenu = countMenus - 1;
	var l = document.getElementById("menuLayer" + nLastMenu);
	
	// Retrieve all offset between Menucontainer and Body //
	var obj = l.parentNode;
	var offsetLeft = (obj) ? obj.offsetLeft : 0;
	var offsetTop = (obj) ? obj.offsetTop : 0;
	var scrollLeft = (obj) ? obj.scrollLeft : 0;
	var scrollTop = (obj) ? obj.scrollTop : 0;
	do
	{
		obj = obj.parentNode;
		if(!obj)
			break;
	
		var oname = obj.nodeName;
		offsetLeft += obj.offsetLeft;
		offsetTop += obj.offsetTop;
		scrollLeft += obj.scrollLeft;
		scrollTop += obj.scrollTop;
		if(oname == "BODY")
			break;
	} while(oname != null)
	
	hideActiveMenus(l);
	if(typeof(menu) == "string") 
	{
        l = document.getElementById(menu);
        for (var n=0; n < menuContainers.length; n++) 
		{
            l = menuContainers[n].menus[menu];
            for (var i=0; i < menuContainers[n].menus.length; i++) 
			{
                if (menu == menuContainers[n].menus[i].label) 
					l = menuContainers[n].menus[i].menuLayer;
                if (l) 
					break;
            }
        }
    }
    window.ActiveMenu = l;
    l.style.visibility = "inherit";
    
	var WinLeftEdge = document.body.scrollLeft;
	var WinTopEdge = document.body.scrollTop;
	var WinWidth = document.body.offsetWidth;
	var WinHeight = document.body.offsetHeight;
	var WinRightEdge = (WinLeftEdge + WinWidth) - ExtraSpace;
	var WinBottomEdge = (WinTopEdge + WinHeight) - ExtraSpace;
	var menuOffsetX = 0;
	var menuOffsetY = 0;
	var menuLeftEdge = 0;
	var menuTopEdge = 0;

	l.style.left = window.pageX + "px";
	l.style.top = window.pageY +"px";
	l.Menu.xOffset = scrollLeft;
    l.Menu.yOffset = scrollTop;
    if(menu)
		window.activeMenus[window.activeMenus.length] = l;
}

function hideMenu(e) 
{
	var l;
	if(!e) l = window.ActiveMenu;
	else
	{
		l = e.currentTarget;
		l = document.getElementById(l.id);// SAFARI
	}

	l = window.ActiveMenu;
	if(!l)
		return;

    if (l.menuLayer) 
        l = l.menuLayer;
	else if (this.style)
        l = this;
    
    document.saveMousemove = document.onmousemove;
    document.onmousemove = mouseTracker;
	if (window.ActiveMenu)
	{
        document.onmousedown=null;
        if (window.ActiveMenu.Menu) 
		{
            if (window.ActiveMenu.Menu.disableHide) return true;
			   e = window.event || e;
			if(!window.ActiveMenu.Menu.enableHideOnMouseOut && !e)
			{
				hideActiveMenus(l);
				return true;
			}
            if (!window.ActiveMenu.Menu.enableHideOnMouseOut && e.type == "mouseout") 
				return true;
        }
    }
   
    hideActiveMenus(l);
    return true;
}

function hideChildMenu(menuLayer) 
{
    var l = menuLayer || this;
    if(l.Menu.childMenus)
	{
		for (var i=0; i < l.Menu.childMenus.length; i++)	
		{
			if(l.Menu.childMenus[i])	
			{
				l.Menu.childMenus[i].style.visibility = "hidden";
				if(l.Menu.childMenus[i].Menu)
					l.Menu.childMenus[i].Menu.hideChildMenu(l.Menu.childMenus[i]);
			}
		}
	}
    if (l.childMenu) 
	{
		l.childMenu.style.zIndex = l.Menu.menuLayer.style.zIndex + 1;
		l.childMenu.style.top = parseInt(l.style.top) + parseInt(l.Menu.menuLayer.style.top); // WARNING

		var childWidth = parseInt(l.childMenu.style.left);
		if(!isNaN(parseInt(l.childMenu.offsetWidth)))
			childWidth = parseInt(childWidth) + parseInt(l.childMenu.offsetWidth);
		if (childWidth > document.width)
		{
 			l.childMenu.style.left = parseInt(l.childMenu.offsetWidth) + parseInt(l.Menu.menuLayer.style.top) + 15;
		}

		var WinLeftEdge = window.pageXOffset;
		var WinTopEdge = window.pageYOffset;
		var WinWidth = window.innerWidth;
		var WinHeight = window.innerHeight;
		var WinRightEdge = (WinLeftEdge + WinWidth) - ExtraSpace; // 10 is the extra Space
		var WinBottomEdge = (WinTopEdge + WinHeight) - ExtraSpace;
	
/*		if(WinRightEdge < (l.Menu.menuLayer.style.left + l.Menu.menuLayer.style.pixelWidth + l.style.pixelWidth + ExtraSpace))
			l.childMenu.style.left = l.Menu.menuLayer.style.left - l.childMenu.style.pixelWidth + WinRightEdge - ExtraSpace;
		else
			l.childMenu.style.left = l.Menu.menuLayer.style.pixelWidth + l.Menu.menuLayer.style.left -5;
*/
		childWidth = parseInt(l.childMenu.style.left);
		if(!isNaN(l.childMenu.offsetWidth))
			childWidth = parseInt(childWidth) + parseInt(l.childMenu.offsetWidth) + ExtraSpace;
		if(WinRightEdge < childWidth)
		{
			// check if we could display sub menu to the left of the parent menu
		/*	if(WinLeftEdge  < (l.childMenu.style.left - l.childMenu.offsetWidth - ExtraSpace))
			{
				l.childMenu.style.left = l.Menu.menuLayer.style.left - l.childMenu.offsetWidth - ExtraSpace;
			}
			else */
				l.childMenu.style.left = WinRightEdge - l.childMenu.offsetWidth;
		}
		else
		{
			l.childMenu.style.left = l.Menu.menuLayer.offsetWidth + parseInt(l.Menu.menuLayer.style.left) -5;
		}
			
		if(WinBottomEdge < (parseInt(l.childMenu.style.top) + l.childMenu.offsetHeight + ExtraSpace))
		{
			if(window.pageY - l.childMenu.style.offsetHeight - ExtraSpace > 0)
				l.childMenu.style.top = WinBottomEdge - l.childMenu.offsetHeight - ExtraSpace;
		}
		l.childMenu.style.visibility = "inherit";
        if (!l.childMenu.disableHide) 
            window.activeMenus[window.activeMenus.length] = l.childMenu;
    }
}

function hideActiveMenus(l)
{ 
	if (!window.activeMenus) return;
    for (var i=0; i < window.activeMenus.length; i++) 
	{
		if (!activeMenus[i])
			return;
        if (activeMenus[i].style.visibility && activeMenus[i].Menu)
		{
            activeMenus[i].style.visibility = "hidden";
            activeMenus[i].Menu.container.style.visibility = "hidden";
            activeMenus[i].Menu.container.style.clip.left = 0;
		} 
		else if (activeMenus[i].style) 
			activeMenus[i].style.visibility = "hidden";
    }
    document.onmousemove = mouseTracker;
    window.activeMenus.length = 0;
}

function mouseTracker(e) 
{
    e = e || window.Event || window.event;
    window.pageX = e.pageX || e.clientX; window.pageY = e.pageY || e.clientY;
}

function setMouseTracker() 
{
    if (document.captureEvents) document.captureEvents(Event.MOUSEMOVE|Event.MOUSEUP);
	document.onmousemove = this.mouseTracker;document.onmouseup = this.hideMenu;
}

function onMenuItemDown(e, l) 
{
    l = l || window.ActiveMenuItem || this;
    if (!l.Menu) 
	{
    } 
	else 
		window.event.cancelBubble=true;
}

function KeyControl(e)
{
	if(e.keyCode == 27)
		hideMenu();
}

function Hide(e)
{
	hideMenu();
}

function FindMaxWidth4MenuItem(menuItemObj, menu)
{
	var ItemWidthMax	=	150; // default Max width for item
	var ItemWidthMin	=	15;		// default Min width for item
	var bUseItemWidthMax  = false;
	var menuCount = gcountMenusItem4Width;
	if(!menuItemObj)
		return ItemWidthMax; 
	for(i = 0; i < menuItemObj.items.length; i++)
	{
		var l = document.getElementById("menuItem" + menuCount);
		if(!l)
			return ItemWidthMax;

		var ItemWidth = 0;
		var objMenuItemText = document.getElementById("menuItemText" + menuCount);
		if(objMenuItemText)
		{
			ItemWidth = objMenuItemText.offsetWidth;
		}
		else 
			ItemWidth = 250;

		if(ItemWidth + 10 > ItemWidthMax)
		{
			ItemWidthMax = ItemWidth + 10;
			bUseItemWidthMax = true;
		}
		else if(ItemWidth + 10 > ItemWidthMin)
			ItemWidthMin = ItemWidth + 10;
		
		menuCount++;
	}
	gcountMenusItem4Width += menuItemObj.items.length;
	return (bUseItemWidthMax) ? ItemWidthMax : ItemWidthMin;
}

function removeMenu(container, menu) // this fonction is used only for Safari browser on MAC
{
	if(menu.hasChildNodes())
	{
		menuChildList = menu.childNodes;
		for(var o=0; o <menuChildList.length;o++)
		{
			var menuChild = menuChildList.item(o);
			removeMenu(menu, menuChild);
		}
	}
	
	container.removeChild(menu);
}
//-->