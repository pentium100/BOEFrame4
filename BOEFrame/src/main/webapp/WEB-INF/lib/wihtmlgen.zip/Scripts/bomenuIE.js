<!--
var countMenus = 0;
var firstMenu = 0;
var ExtraSpace = 10;

var CellWihtDrillOnFocus = "";
var BgColorCellSaved = "";
var gcountMenusItem4Width = 0;

function Menu(label) 
{
    this.type					=		"Menu";
    this.menuBorder				=		2;
    this.menuItemBorder			=		0;
	this.menuItemHeight			=		22;
    this.childMenuIcon			=		"images/menu_arrows.gif";
    this.childMenuIconHilite	=		"images/menu_arrows.gif";
	this.use4DrillDoc			=		true; 

	this.MenuItemPicture		=		new Array();
    this.items					=		new Array();
    this.actions				=		new Array();
    this.colors					=		new Array();
    this.mouseovers				=		new Array();
    this.mouseouts				=		new Array();
    this.childMenus				=		new Array();
	this.ExtraInfo4Items		=		new Array();
	this.tooltips				=		new Array();

    this.addMenuItem			=		addMenuItem;
    this.addMenuSeparator		=		addMenuSeparator;
    this.writeMenus				=		writeMenus;
    this.showMenu				=		showMenu;
    this.onMenuItemOver			=		onMenuItemOver;
    this.onMenuItemOut			=		onMenuItemOut;
    this.onMenuItemDown			=		onMenuItemDown;
    this.onMenuItemAction		=		onMenuItemAction;
    this.hideMenu				=		hideMenu;
    this.hideChildMenu			=		hideChildMenu;
    this.mouseTracker			=		mouseTracker;
    this.setMouseTracker		=		setMouseTracker;
	this.Action					=		Action;

    if (!window.menus) 
		window.menus = new Array();
    this.label = label || "menuLabel" + window.menus.length;
    window.menus[this.label] = this;
    window.menus[window.menus.length] = this;
    if (!window.activeMenus) 
		window.activeMenus = new Array();
    if (!window.menuContainers) 
		window.menuContainers = new Array();
	this.setMouseTracker();
}

function addMenuItem(label, action, color, mouseover, mouseout, extrainfo, tooltip, picture) 
{
    this.items[this.items.length] = label;
    this.actions[this.actions.length] = action;
    this.colors[this.colors.length] = color;
    this.mouseovers[this.mouseovers.length] = mouseover;
    this.mouseouts[this.mouseouts.length] = mouseout;
	this.ExtraInfo4Items[this.ExtraInfo4Items.length] = extrainfo;
	this.tooltips[this.tooltips.length] = tooltip;
	this.MenuItemPicture[this.MenuItemPicture.length] = picture;
}

function Action(valid, DrillAction, BID, PBID, DimFrom, HierTo, DimTo, DrillFilter, SortValue, ivAction)
{
	this.valid	= valid;
	this.DrillAction = DrillAction;
	this.BID = BID;
	this.PBID = PBID;	
	this.DimFrom = DimFrom;
	this.HierTo = HierTo;
	this.DimTo = DimTo;
	this.DrillFilter = DrillFilter;
	this.SortValue = SortValue;
	this.IVAction = ivAction;
}

function addMenuSeparator() 
{
    this.items[this.items.length] = "separator";
    this.actions[this.actions.length] = "";
	this.ExtraInfo4Items[this.ExtraInfo4Items.length] = "";
    this.menuItemBorder = 1;
}
////////////////////////////////////////////////////////////////////////////////////////////////

function writeMenus(container) 
{
	if (!container) 
	{
		if (!document.all["menuContainer"]) 
			document.write('<SPAN ID="menuContainer"></SPAN>');
		container = document.all["menuContainer"];
	}
    if (!container && !window.delayWriteMenus) 
	{
        window.delayWriteMenus = this.writeMenus;
        setTimeout('delayWriteMenus()', 3000);
        return;
    }

    container.isContainer = "menuContainer" + menuContainers.length;
    menuContainers[menuContainers.length] = container;
    container.menus = new Array();

    for (var i=0; i < window.menus.length; i++) 
		container.menus[i] = window.menus[i];

    window.menus.length = 0;
    var countItems = 0;
    var top = 0;
    var content = '';
    var proto;

	firstMenu = countMenus // initialize index of first menu

    for (var i=0; i < container.menus.length; i++, countMenus++) 
	{
        var menu = container.menus[i];

        proto = menu.prototypeStyles || this.prototypeStyles || menu;
        content += ''+
        '<DIV ID="menuLayer'+countMenus+'" CLASS="Menu" STYLE="left:10;top:'+ (i * 100) +';visibility:hidden;">'+
	    '<DIV ID="menuLite'+countMenus+'" STYLE="position:absolute;left:'+ proto.menuBorder +';top:'+ proto.menuBorder +';visibility:hide;" onmouseout="hideMenu(this);">'+
		'<DIV ID="menuFg'+countMenus+'" STYLE="position:absolute;visibility:inherit;">';
        
        for (var j=0; j<menu.items.length; j++) 
		{
            var item = menu.items[j];
            var childMenu = false;
            if (item.label) 
			{
                item = item.label;
                childMenu = true;
            } 
			            
			var itemProps = 'visibility:hide;';

			if (menu.actions[j]!='DISABLED')
				itemProps += ';" onmouseover="onMenuItemOver(this);" onmouseout="onMenuItemOut(this);" onmousedown="onMenuItemAction(null,this);';

			var skin = '';
			if(menu.MenuItemPicture[j])
			{
				skin += menu.MenuItemPicture[j];
			}
       
		  	var dTag    = '<DIV ID="menuItem'+ countItems +'" CLASS="MenuFont MenuItemDefault" STYLE="position:absolute;left:0;top:'+ (j * proto.menuItemHeight) +';'+ itemProps +'">';
		    var dText;
            
			if (menu.actions[j]!='DISABLED')
			{
				var tooltips = '';
				if(menu.tooltips[j])
					tooltips = 'TITLE="' + menu.tooltips[j] + '"';
				dText = '<DIV UNSELECTABLE="on" NOWRAP=true CLASS="' + skin + ' MenuFont"' + tooltips + 'ID="menuItemText'+ countItems +'" STYLE="position:absolute;left:0;top:0;">'+ item +'</DIV>';
			}
			else
				dText = '<DIV UNSELECTABLE="on" CLASS="' + skin + ' MenuFontDisabled" NOWRAP=true ID="menuItemText'+ countItems +'" STYLE="position:absolute;left:0;top:0;">'+ item +'</DIV>';
            if (item == "separator")
			{
				var dTagSep    = '<DIV ID="menuItem'+ countItems +'" STYLE="position:absolute;left:0;top:'+ (j * (1)) +';'+ itemProps +'">';
				content += ( dTagSep + '<DIV NOWRAP=true ID="menuSeparator'+ countItems +'" STYLE="position:absolute;left:1;top:2;"></DIV>\n<DIV ID="menuSeparatorLite'+ countItems +'" STYLE="position:absolute;left:1;top:2;"></DIV></DIV>');
			}
            else if (childMenu)
				content += ( dTag + dText + '<DIV CLASS="MenuFont" ID="childMenu'+ countItems +'" STYLE="position:absolute;left:0;top:3;'+ itemProps +'"><IMG SRC="'+ proto.childMenuIcon +'"></DIV></DIV>');
            else 
				content += ( dTag + dText + '</DIV>');
            
            countItems++;
        }
        content += '</DIV></DIV></DIV>';
    }
    if (!container) return;

	container.innerHTML = content;

	proto = null;
    var menuCount = 0;
    var ItemWidthMax = 0;
	gcountMenusItem4Width = 0;

    for (var x=0; x < container.menus.length; x++) 
	{
		var xoffset = firstMenu + x;
        var menu = container.document.all("menuLayer" + xoffset);
		container.menus[x].menuLayer = menu;
        container.menus[x].menuLayer.Menu = container.menus[x];
        container.menus[x].menuLayer.Menu.container = menu;
        proto = container.menus[x].prototypeStyles || this.prototypeStyles || container.menus[x];
        proto.menuItemWidth = proto.menuItemWidth || 250;

		ItemWidthMax = FindMaxWidth4MenuItem(container.menus[x], menu);

        for (var i=0; i < container.menus[x].items.length; i++) 
		{
			var l = menu.all["menuItem" + menuCount];

            l.Menu = container.menus[x];
            proto = container.menus[x].prototypeStyles || this.prototypeStyles || container.menus[x];
           
            l.style.pixelWidth = ItemWidthMax;
           if(l.Menu.items[i] == "separator") l.style.pixelHeight = 2;
           else l.style.pixelHeight = proto.menuItemHeight;
           
            l.style.visibility = "inherit";
            l.action = container.menus[x].actions[i];
            l.mouseover = l.Menu.mouseovers[x];
			l.mouseout  = l.Menu.mouseouts[x];
			l.ExtraInfo = container.menus[x].ExtraInfo4Items[i];
			l.tooltip = container.menus[x].tooltips[i];

			var itemText = menu.all["menuItemText" + menuCount];
			if(itemText)
			{
				itemText.style.pixelHeight = l.clientHeight;
				itemText.style.pixelTop =  (l.clientHeight - itemText.clientHeight) / 2;
			}

		    var childItem = menu.all["childMenu" + menuCount];
            if (childItem) 
			{
				l.style.pixelHeight = proto.menuItemHeight;
	            if (i>0) 
					l.style.pixelTop = menu.all["menuItem" + (menuCount -1)].style.pixelTop + menu.all["menuItem" + (menuCount -1)].style.pixelHeight;

                l.childMenu = container.menus[x].items[i].menuLayer;
                childItem.style.pixelLeft = l.style.pixelWidth -11;
                childItem.style.pixelTop = (l.style.pixelHeight /2) -4;
                childItem.style.clip = "rect(0 7 7 3)";
                l.Menu.childMenus[l.Menu.childMenus.length] = l.childMenu;
            }

			var sep = menu.all["menuSeparator" + menuCount];
            if (sep) 
			{
				l.style.pixelHeight = 2;//proto.menuItemHeight;
	            if (i>0) 
					l.style.pixelTop = menu.all["menuItem" + (menuCount -1)].style.pixelTop + menu.all["menuItem" + (menuCount -1)].style.pixelHeight + proto.menuItemBorder; // WARNING

                sep.style.clip = "rect(0 " + (proto.menuItemWidth - 3) + " 1 0)";
                sep.style.backgroundColor = "#ff0000";//proto.bgColor;
                sep = menu.all["menuSeparatorLite" + menuCount];

                sep.style.clip = "rect(1 " + (proto.menuItemWidth - 3) + " 2 0)";
                sep.style.backgroundColor = "#ff0000";//proto.menuLiteBgColor; //WARNING
                l.style.pixelHeight = proto.menuItemHeight;
                l.isSeparator = true;
			}
            menuCount++;
        }
        if(l)
           proto.menuHeight = (l.style.pixelTop + l.style.pixelHeight); 
          
        var lite = menu.all["menuLite" + xoffset];
		lite.style.pixelHeight = proto.menuHeight;
		lite.style.pixelWidth = ItemWidthMax;
		lite.className = "MenuLite";
		var BorderWidth = eval(menu.currentStyle.borderLeftWidth.slice(0, menu.currentStyle.borderLeftWidth.length - 2)) + eval(menu.currentStyle.borderRightWidth.slice(0, menu.currentStyle.borderRightWidth.length - 2));
		var BorderHeight = eval(menu.currentStyle.borderTopWidth.slice(0, menu.currentStyle.borderTopWidth.length - 2)) + eval(menu.currentStyle.borderBottomWidth.slice(0, menu.currentStyle.borderBottomWidth.length - 2));
		container.menus[x].menuLayer.style.pixelWidth = ItemWidthMax + (2 * proto.menuBorder) + BorderWidth;
		container.menus[x].menuLayer.style.pixelHeight = proto.menuHeight + (2 * proto.menuBorder) + BorderHeight;
   
        if (menu.Menu.enableTracker) 
		{
            menu.Menu.disableHide = true;
            setMenuTracker(menu.Menu);
        }
    }

    window.wroteMenu = true;
}

function onMenuItemOver(l, a) 
{
    l = l || this;
	if (l.style) 
	{
		if (l.Menu==null)
			return
        document.onmousedown=l.Menu.onMenuItemDown;
        if (l.isSeparator) 
			return;
		if(l.ExtraInfo)
        {
			switch(typeof(l.ExtraInfo))
			{
				case 'string':
					self.status = l.ExtraInfo;
				break;
				case 'object':
					switch(l.ExtraInfo[INDEX_DRILLTYPE])
					{
						case D:
							self.status = _LOC_DRILLDOWNTO + l.ExtraInfo[INDEX_DIMNAME];
						break;
						case U:
							self.status = _LOC_DRILLUPTO + l.ExtraInfo[INDEX_DIMNAME];
						break;
						case B:
							self.status = _LOC_DRILLBY + l.ExtraInfo[INDEX_DIMNAME];
						break;
					}
				break;
			}
        }
		l.className = "MenuFont MenuItemOver";
        l.Menu.hideChildMenu(l);
    }
}

function onMenuItemOut(l, a) 
{
    l = l || this;
	if(l)
	{
		self.status = 'l.id = ' + l.id + "   CLASSNAME = " + l.className;
		l.className = "MenuFont MenuItemDefault";
		window.event.cancelBubble=true;

	}
	//if (a && l.style) 
	{
//	     document.onmousedown=null;
  //     window.event.cancelBubble=true;
	}
    self.status = '';
}

function onMenuItemAction(e, l) 
{
	if (!l) 
		return;
	if(!l.action)
		return;
	if (!ActiveMenu.Menu.disableHide) 
		hideActiveMenus(ActiveMenu.menuLayer);

	if (l.action) 
	{
		if (ActiveMenu.Menu.use4DrillDoc) 
			GenerateURL(l.action);
		else
			eval("" + l.action);
	}
}

function showMenu(menu, x, y, child) 
{
	if (!window.wroteMenu) 
		return;
	var nLastMenu = countMenus - 1;
	var l = document.all("menuLayer" + nLastMenu);
	
	// Retrieve all offset between Menucontainer and Body //
	var obj = l.parentElement;
	var offsetLeft = (obj) ? obj.style.pixelLeft : 0;
	var offsetTop = (obj) ? obj.style.pixelTop : 0;
	var scrollLeft = (obj) ? obj.scrollLeft : 0;
	var scrollTop = (obj) ? obj.scrollTop : 0;
	do
	{
		obj = obj.parentElement;
		if(!obj)
			break;
	
		var oname = obj.tagName;
		offsetLeft += obj.style.pixelLeft;
		offsetTop += obj.style.pixelTop;
		scrollLeft += obj.scrollLeft;
		scrollTop += obj.scrollTop;
		if(oname == "BODY")
			break;
	} while(oname != null)
	
	hideActiveMenus(l);
	if(typeof(menu) == "string") 
	{
        l = document.all[menu];
        for (var n=0; n < menuContainers.length; n++) 
		{
            l = menuContainers[n].menus[menu];
            for (var i=0; i < menuContainers[n].menus.length; i++) 
			{
                if (menu == menuContainers[n].menus[i].label) 
					l = menuContainers[n].menus[i].menuLayer;
                if (l) 
					break;
            }
        }
    }
    window.ActiveMenu = l;
	
    l.style.visibility = "inherit";
    
	// BEN ADDIN
	var WinLeftEdge = document.body.scrollLeft;
	var WinTopEdge = document.body.scrollTop;
	var WinWidth = document.body.clientWidth;
	var WinHeight = document.body.clientHeight;
	var WinRightEdge = (WinLeftEdge + WinWidth) - ExtraSpace;
	var WinBottomEdge = (WinTopEdge + WinHeight) - ExtraSpace;
	var menuOffsetX = 0;
	var menuOffsetY = 0;
	var menuLeftEdge = 0;
	var menuTopEdge = 0;

	if (x != "relative")
	{ 
		if(WinRightEdge < ( window.pageX + l.style.pixelWidth + ExtraSpace))
			menuOffsetX = - l.style.pixelWidth;
		//l.style.pixelLeft = x || (window.pageX + document.body.scrollLeft) || 0;
		l.style.pixelLeft = x || (window.pageX + scrollLeft) || 0;
		l.style.pixelLeft += menuOffsetX;

		if(WinLeftEdge > l.style.pixelLeft)
			l.style.pixelLeft += ((WinLeftEdge + ExtraSpace) - l.style.pixelLeft);
	}
    if (y != "relative") 
	{
		
        if(WinBottomEdge < ( window.pageY + l.style.pixelHeight + ExtraSpace))
		{
			if(window.pageY - l.style.pixelHeight - ExtraSpace > 0)
				menuOffsetY = - l.style.pixelHeight;
		}
		//l.style.pixelTop = y || (window.pageY + document.body.scrollTop) || 0;
		l.style.pixelTop = y || (window.pageY + scrollTop) || 0;
		l.style.pixelTop += menuOffsetY;
	}
	// END BEN ADDIN
	
	l.style.pixelLeft -= offsetLeft;
	l.style.pixelTop -= offsetTop;
		
	l.Menu.xOffset = scrollLeft;
    l.Menu.yOffset = scrollTop;
    if(menu) 
        window.activeMenus[window.activeMenus.length] = l;
}

function hideMenu(e) 
{
    var l = e || window.ActiveMenu;
    if (!l) return true;
    if (l.menuLayer) 
        l = l.menuLayer;
	else if (this.visibility) 
        l = this;
    if (l.menuLayer) 
        l = l.menuLayer;
    document.saveMousemove = document.onmousemove;
    document.onmousemove = mouseTracker;
	if (window.ActiveMenu) 
	{
        document.onmousedown=null;
	    if (window.ActiveMenu.Menu) 
		{
            if (window.ActiveMenu.Menu.disableHide) return true;
			    e = window.event || e;
			if(!window.ActiveMenu.Menu.enableHideOnMouseOut && !e)
			{
				hideActiveMenus(l);
				return true;
			}
            if (!window.ActiveMenu.Menu.enableHideOnMouseOut && e.type == "mouseout") 
				return true;
        }
    }
   
    hideActiveMenus(l);
    return true;
}

function hideChildMenu(menuLayer) 
{
    var l = menuLayer || this;
    for (var i=0; i < l.Menu.childMenus.length; i++) 
	{
		l.Menu.childMenus[i].style.visibility = "hidden";
		l.Menu.childMenus[i].Menu.hideChildMenu(l.Menu.childMenus[i]);
    }
    if (l.childMenu) 
	{
		l.childMenu.style.zIndex = l.Menu.menuLayer.style.zIndex +1;
		l.childMenu.style.pixelTop = l.style.pixelTop + l.Menu.menuLayer.style.pixelTop;
		if (l.childMenu.style.pixelLeft + l.childMenu.style.pixelWidth > document.width) 
			l.childMenu.style.pixelLeft = l.childMenu.style.pixelWidth + l.Menu.menuLayer.style.pixelTop + 15;

		// BEN ADDIN WARNING
		var WinLeftEdge = document.body.scrollLeft;
		var WinTopEdge = document.body.scrollTop;
		var WinWidth = document.body.clientWidth;
		var WinHeight = document.body.clientHeight;
		var WinRightEdge = (WinLeftEdge + WinWidth) - ExtraSpace; // 10 is the extra Space
		var WinBottomEdge = (WinTopEdge + WinHeight) - ExtraSpace;
	
		if(WinRightEdge < (l.childMenu.style.pixelLeft + l.childMenu.style.pixelWidth + ExtraSpace))
		{
			// check if we could display sub menu to the left of the parent menu
				l.childMenu.style.pixelLeft = WinRightEdge - l.childMenu.style.pixelWidth;
		}
		else
			l.childMenu.style.pixelLeft = l.Menu.menuLayer.style.pixelWidth + l.Menu.menuLayer.style.pixelLeft -5;
			
		if(WinBottomEdge < (l.childMenu.style.pixelTop + l.childMenu.style.pixelHeight + ExtraSpace))
		{
			if(window.pageY - l.childMenu.style.pixelHeight - ExtraSpace > 0)
				l.childMenu.style.pixelTop = WinBottomEdge - l.childMenu.style.pixelHeight - ExtraSpace;
		}
		// END BEN ADDIN

		l.childMenu.style.visibility = "inherit";
        if (!l.childMenu.disableHide) 
            window.activeMenus[window.activeMenus.length] = l.childMenu;
    }
}

function hideActiveMenus(l)
{
    if (!window.activeMenus) return;
    for (var i=0; i < window.activeMenus.length; i++) 
	{
		if (!activeMenus[i])
			return;
        if (activeMenus[i].visibility && activeMenus[i].Menu) 
		{
            activeMenus[i].visibility = "hidden";
            activeMenus[i].Menu.container.visibility = "hidden";
            activeMenus[i].Menu.container.clip.left = 0;
        } 
		else if (activeMenus[i].style) 
			activeMenus[i].style.visibility = "hidden";
    }
    document.onmousemove = mouseTracker;
    window.activeMenus.length = 0;
}

function mouseTracker(e) 
{
    e = e || window.Event || window.event;
    window.pageX = e.pageX || e.clientX;
    window.pageY = e.pageY || e.clientY;
}

function setMouseTracker() 
{
    if (document.captureEvents) 
		document.captureEvents(Event.MOUSEMOVE|Event.MOUSEUP);
	document.onmousemove = this.mouseTracker;
	document.onmouseup = this.hideMenu;
}

function onMenuItemDown(e, l) 
{
}

function KeyControl()
{
	if(window.event.keyCode == 27)
		hideMenu();
			
}

function FindMaxWidth4MenuItem(menuItemObj, menu)
{
	var ItemWidthMax	=	150; // default Max with for item
	var ItemWidthMin	=	15;		// default Min width for item
	var bUseItemWidthMax  = false;
	var menuCount = gcountMenusItem4Width;
	if(!menuItemObj)
		return ItemWidthMax; 
	for(i = 0; i < menuItemObj.items.length; i++)
	{
		var l = menu.all["menuItem" + menuCount];
		if(!l)
			return ItemWidthMax;

		var ItemWidth = 0;
			var objMenuItemText = l.all("menuItemText" + menuCount);
		if(objMenuItemText)
		{
			ItemWidth = objMenuItemText.clientWidth;
			objMenuItemText.pixelHeight = 50;
		}
		else 
			ItemWidth = 250;

		if(ItemWidth + 10 > ItemWidthMax)
		{
			ItemWidthMax = ItemWidth + 10;
			bUseItemWidthMax = true;
		}
		else if(ItemWidth + 10 > ItemWidthMin)
			ItemWidthMin = ItemWidth + 10;
		
		menuCount++;
	}
	gcountMenusItem4Width += menuItemObj.items.length;
	return (bUseItemWidthMax) ? ItemWidthMax : ItemWidthMin;
}
//-->