<!--
//---------------------------------------------------------------------
// Global variables
//---------------------------------------------------------------------
var COUNT_DRILL=3;//3 drill actions possible
var INDEX_DRILLTYPE=0;
var INDEX_HIERARCHYID=1;
var INDEX_HIERARCHYNAME=2;
var INDEX_DIMID=3;
var INDEX_DIMNAME=4;
var INDEX_SCOPE=5;
var idTimer=-1;
var gHoverElement;
var gDrillPathIDCurrent="-1";
var gDimFromID="-1";
var gPBIDWithDrillOnFocus="-1";
var gDrillFilter="-1";
var MaxMenuItemLength=20;
var D='down';	// Drill down Type
var U='up';	// Drill Up Type
var B='by';	// Drill by Type

var gActionPending = false;
function sc (element, bShow)
{
	var	strCursor;
	if (bShow){if(bw.ie6x || bw.ns5) strCursor = "pointer";else if(bw.ie5x) strCursor="hand";}
	else strCursor="default";
	element.style.cursor=strCursor;
	if(bw.saf != 1)
		element.title = _LOC_TOOLTIP;
}

function ctxm(element, DP_ID, PBID, DimFromID, DrillFilter, BID){ if(event.button == 2) cm (element, DP_ID, PBID, DimFromID, DrillFilter, BID); return false;}

function cm (element, DP_ID, PBID, DimFromID, DrillFilter, BID)
{
	if(gActionPending == true)return;

	if("undefined" != typeof(element)) {sc (element, true);gHoverElement = element;}
	else {gHoverElement = null;return;}

	// check case header not drillable
	if(("undefined" != typeof(DP_ID)) && ("undefined" == typeof(BID)) && ("undefined" == typeof(PBID)) && ("undefined" == typeof(DimFromID)))
	{
		BID = DP_ID;DP_ID = null;
		if('undefined' == typeof(actionTable[BID]) && 'undefined' == typeof(graphTable[BID]))	{gHoverElement=null;hideMenu();return;}
	}
	
	gDrillPathIDCurrent = DP_ID;gDimFromID = DimFromID;CellWihtDrillOnFocus = BID;gBIDWihtDrillOnFocus = BID;gPBIDWithDrillOnFocus = PBID;gDrillFilter = DrillFilter;
	if(bw.saf)
		idTimer = window.setTimeout("OnCreate2(" + 'gDrillPathIDCurrent' + "," + 'gPBIDWithDrillOnFocus' + "," + 'gDimFromID' + "," + 'gDrillFilter'+ "," + 'gBIDWihtDrillOnFocus' +")", 700);
	else
		OnCreate2(gDrillPathIDCurrent,gPBIDWithDrillOnFocus,gDimFromID,gDrillFilter,gBIDWihtDrillOnFocus);
}

function hm(){clearTimeout(idTimer);}

if(document.captureEvents){document.captureEvents(Event.MOUSEMOVE|Event.MOUSEUP);}

function DP(id){this.id=id;this.dd=new Array();this.du=new Array();this.db=new Array();this.ds=new Array();this.AddDrillOp=AddDrillOp;}	
function ActionDesc(sort, filter,calc,bottomCalc){var o=this;o.sort=sort;o.filter=filter;o.calc=calc;o.bottomCalc=bottomCalc;}
function calcDesc(sum,count,avg,min,max,percent){var o=this;o.sum=sum;o.count=count;o.avg=avg;o.min=min;o.max=max;o.percent=percent;}
function graphVar(name,id,axis,sort,filter,qualif){var o=this;o.name=name;o.id=id;o.axis=axis;o.sort=sort;o.filter=filter;o.qualif=qualif;}
function graphDesc(vars,x,y,z){	var o=this;o.vars=vars;o.x=x;o.y=y;o.z=z;}
function InteractiveAction(){var o=this;o.reason=null;o.bid=null;o.sort=null;o.calc=null;o.bottomCalc=null;o.id=null;o.axis=null;o.axisIndex=0;}
function IVAction(reason, bid,bottom){var o=this;o.reason=reason;o.bid=bid;o.sort=null;o.calc=null;o.bottomCalc=bottom;o.id=null;o.axis=null;o.axisIndex=0;}
function InteractiveAction(a){var o=this;o.reason=a.reason;o.bid=a.bid;o.sort=a.sort;o.calc=a.calc;o.bottomCalc=a.bottomCalc;o.id=a.id;o.axis=a.axis;o.axisIndex=a.axisIndex;}

function AddDrillOp(type, Hid, Hname, Dimid, Dimname, scopeFlag)
{
	if(type == D) drillarray = this.dd;	
	else if(type == U) drillarray = this.du;
	else if(type == B) drillarray = this.db;
	else if(type == S) drillarray = this.ds;
	else return;
	var Hlength = drillarray.length;drillarray[Hlength] = new Array(6);drillarray[Hlength][INDEX_DRILLTYPE]=type;drillarray[Hlength][INDEX_HIERARCHYID]=Hid;drillarray[Hlength][INDEX_HIERARCHYNAME]=Hname;drillarray[Hlength][INDEX_DIMID]=Dimid;drillarray[Hlength][INDEX_DIMNAME]=Dimname;drillarray[Hlength][INDEX_SCOPE]=scopeFlag;
}

// functions usefull to address Drill request to server
//////////////////////////////////////////////////////
function GenerateURL(action)
{
	gActionPending = true;
	if('undefined' != typeof(action.IVAction))
	{
		applyInteractiveViewing(new InteractiveAction(action.IVAction));
		return true;
	}

	var oForm = document.createElement("FORM");
	oForm.id = "Form2SDKDRILL";oForm.name = "Form2SDKDRILL";oForm.action = DrillSDKURL;oForm.method = "POST";oForm.target = DrillTargetFrame;

	// drillaction
	var oInput = document.createElement("INPUT");oInput.type = "hidden";oInput.name = DrillActionHolder;oInput.value = action.DrillAction;oForm.appendChild(oInput);
	// PBID
	var oInput = document.createElement("INPUT");oInput.type = "hidden";oInput.name = BlockHolder;oInput.value = action.PBID;oForm.appendChild(oInput);
	//	storageKey
	var oInput = document.createElement("INPUT");oInput.type = "hidden";oInput.name = StorageHolder;oInput.value = StorageKey;oForm.appendChild(oInput);
	// DimFrom
	for(i = 0; i < action.DimFrom.length; i++)
	{
		var oInput = document.createElement("INPUT");oInput.type = "hidden";oInput.name = DrillDimFromHolder;
		if('object' == typeof(action.DimFrom)) oInput.value = action.DimFrom[i];
		else{ oInput.value = action.DimFrom;oForm.appendChild(oInput);break;}
		oForm.appendChild(oInput);
	}

	for(i = 0; i < action.DrillFilter.length; i++)
	{
		var oInput = document.createElement("INPUT");oInput.type = "hidden";oInput.name = DrillFilterHolder;
		if('object' == typeof(action.DrillFilter)) oInput.value = action.DrillFilter[i];
		else{ oInput.value = action.DrillFilter;oForm.appendChild(oInput);break; }
		oForm.appendChild(oInput);
	}
	
	for(i = 0; i < action.DimTo.length; i++)
	{
		var oInput = document.createElement("INPUT");oInput.type = "hidden";oInput.name = DrillDimToHolder;
		if('object' == typeof(action.DimTo)) oInput.value = action.DimTo[i];
		else{ oInput.value = action.DimTo;oForm.appendChild(oInput);break; }
		oForm.appendChild(oInput);
	}
	for(i = 0; i < action.HierTo.length; i++)
	{
		var oInput = document.createElement("INPUT");oInput.type = "hidden";oInput.name = DrillHierToHolder;
		if('object' == typeof(action.HierTo)) oInput.value = action.HierTo[i];
		else{ oInput.value = action.HierTo;oForm.appendChild(oInput);break; }
		oForm.appendChild(oInput);
	}

	document.body.appendChild(oForm);
	oForm.submit();
}


function MakeURL4MenuActionItem(valid, DimFromID, BID, PBID, DrillObj, NewDimIndex, DrillFilter)
{
	return new Action(valid, DrillObj[INDEX_DRILLTYPE], BID, PBID, DimFromID, DrillObj[INDEX_HIERARCHYID], DrillObj[INDEX_DIMID], DrillFilter);
}
function OnCreate2(DP_ID, PBID, DimFromID, DrillFilter, BID) 
{
	var bMenuEmpty = true;

	// Find DrillPath with DP_ID
	var DPObj = FindDrillPathAr(DP_ID);

	// Restore initial cursor
	if("undefined" != gHoverElement)
		sc (gHoverElement, false);
	gHoverElement	= null;

	mm(DPObj, PBID, DimFromID, DrillFilter, BID);
}

// Strings add on

function CheckContent4Menu(SrcString)
{
	var DestString = '';
	StrLen = SrcString.length;
	if (StrLen > MaxMenuItemLength ) {DestString = SrcString.substring(0, MaxMenuItemLength);DestString += "...";return DestString;}
	else
		return SrcString;
}

function gd(DP_ID, DrillAction, PBID, DimFrom, DrillFilter, BID)
{
	
	var DrillObj = FindDrillPathAr(DP_ID);
	if(DrillObj)
	{
		var ambiguousDrill = 0;
		if(DrillAction == D) {var DObj = (DrillObj.dd.length > 0) ? DrillObj.dd : null;ambiguousDrill = DrillObj.dd.length;}
		else if(DrillAction == U) {var DObj = (DrillObj.du.length > 0) ? DrillObj.du : null;ambiguousDrill = DrillObj.du.length;}
		else ambiguousDrill = 0;
		
		if(ambiguousDrill > 1) go4Prompt(DrillAction, BID, PBID, DObj, DimFrom, DrillFilter);
		else
		{
			if(DObj)
			{
				var action = new Action(true,DrillAction, BID, PBID, DimFrom, DObj[0][INDEX_HIERARCHYID],DObj[0][INDEX_DIMID], DrillFilter);
				GenerateURL(action);
			}
			else alert(_LOC_DRILL_NOT_ENABLE);
		}
	}

}

function go4Prompt(drillAction, BID, PBID, DrillObj, DimFrom, DrillFilter)
{
	var container;
	var oForm;

	var oInput;
	container = document.getElementById("DRILLSDK");
	oForm = document.createElement("FORM");
	oForm.id = "PromptFORM";
	oForm.name = "PromptFORM";
	oForm.action = DrillAmbiguousURL;
	oForm.target = DrillTargetFrame;
	oForm.method = "POST";

	oInput = document.createElement("INPUT");
	oInput.type = "hidden";
	oInput.name = DrillActionHolder;
	oInput.value = drillAction;
	oForm.appendChild(oInput);

	oInput = document.createElement("INPUT");
	oInput.type = "hidden";
	oInput.name = StorageHolder;
	oInput.value = StorageKey;
	oForm.appendChild(oInput);

	oInput = document.createElement("INPUT");
	oInput.type = "hidden";
	oInput.name = BlockHolder;
	oInput.value = PBID;
	oForm.appendChild(oInput);


	for(i = 0; i < DimFrom.length; i++)
	{
		oInput = document.createElement("INPUT");
		oInput.type = "hidden";
		oInput.name = DrillDimFromHolder;
		if('object' == typeof(DimFrom))
			oInput.value = DimFrom[i];
		else
		{
			oInput.value = DimFrom;
			oForm.appendChild(oInput);
			break;
		}
		oForm.appendChild(oInput);
	}
	for(i = 0; i < DrillFilter.length; i++)
	{
		oInput = document.createElement("INPUT");
		oInput.type = "hidden";
		oInput.name = DrillFilterHolder;
		if('object' == typeof(DrillFilter))
			oInput.value = DrillFilter[i];
		else
		{
			oInput.value = DrillFilter;
			oForm.appendChild(oInput);
			break;
		}
		oForm.appendChild(oInput);
	}

	for(i = 0; i < DrillObj.length; i++)
	{
		oInput = document.createElement("INPUT");
		oInput.type = "hidden";
		oInput.name = DrillDimToHolder;
		oInput.value = DrillObj[i][INDEX_DIMNAME];
		oForm.appendChild(oInput);

		oInput = document.createElement("INPUT");
		oInput.type = "hidden";
		oInput.name = DrillDimToHolder;
		oInput.value = DrillObj[i][INDEX_DIMID];
		oForm.appendChild(oInput);

		oInput = document.createElement("INPUT");
		oInput.type = "hidden";
		oInput.name = DrillHierToHolder;
		oInput.value = DrillObj[i][INDEX_HIERARCHYNAME];
		oForm.appendChild(oInput);

		oInput = document.createElement("INPUT");
		oInput.type = "hidden";
		oInput.name = DrillHierToHolder;
		oInput.value = DrillObj[i][INDEX_HIERARCHYID];
		oForm.appendChild(oInput);
	}
	document.body.appendChild(oForm);
	oForm.submit();
}

function FindDrillPathAr(DP_ID)
{
	for(i = 0 ;i < DrillPathInfoAr.length; i++)
	{
		if(DrillPathInfoAr[i].id == DP_ID)
			return DrillPathInfoAr[i];
	}
	return null;
}

function sm(DP_ID, DrillType)
{
	var statusMsg = '';
	var DrillObjAr = FindDrillPathAr(DP_ID);
	var Count = 0;
	if(DrillObjAr)
	{
		if(DrillType == D)
		{
			statusMsg = ( DrillObjAr.dd.length > 0) ? _LOC_DRILLDOWNTO : _LOC_UNKNOWN_DRILLACTION;
			for(j = 0; j < DrillObjAr.dd.length; j++)
			{
				if(j > 0) // case with ambiguous drill
					statusMsg += _LOC_OR;
				switch(typeof(DrillObjAr.dd[j][INDEX_DIMNAME]))
				{
					case 'string':
						statusMsg += DrillObjAr.dd[j][INDEX_DIMNAME];
						if(DrillObjAr.dd[j][INDEX_SCOPE] == 'O')
							statusMsg += _LOC_NEWQUERY;
					break;
					case 'object':
						obj = DrillObjAr.dd[j][INDEX_DIMNAME];
						statusMsg += obj[0];
						for(k = 1; k < obj.length; k++)
							statusMsg += _LOC_AND + obj[k];
						if(DrillObjAr.dd[j][INDEX_SCOPE] == 'O')
							statusMsg += _LOC_NEWQUERY;
					break;
				}
			}
		}
		else if(DrillType == U)
		{
			statusMsg = (DrillObjAr.du.length > 0) ? _LOC_DRILLUPTO : _LOC_UNKNOWN_DRILLACTION;
			for(j = 0; j < DrillObjAr.du.length; j++)
			{
				if(j > 0) // case with ambiguous drill
					statusMsg += _LOC_OR;
				switch(typeof(DrillObjAr.du[j][INDEX_DIMNAME]))
				{
					case 'string':
						statusMsg += DrillObjAr.du[j][INDEX_DIMNAME];
						if(DrillObjAr.du[j][INDEX_SCOPE] == 'O')
							statusMsg += _LOC_NEWQUERY;
					break;
					case 'object':
						obj = DrillObjAr.du[j][INDEX_DIMNAME];
						statusMsg += obj[0];
						for(k = 1; k < obj.length; k++)
							statusMsg += _LOC_AND + obj[k];
						if(DrillObjAr.du[j][INDEX_SCOPE] == 'O')
							statusMsg += _LOC_NEWQUERY;
					break;
				}
			}
			
		//	statusMsg += DrillObjAr.du[0][INDEX_DIMARRAY][0][INDEX_DIMAR_NAME];
		}
		else if(DrillType == B)
			statusMsg = _LOC_DRILLBY;
		else
			statusMsg = _LOC_UNKNOWN_DRILLACTION;
	}
	else
		statusMsg = _LOC_UNKNOWN_DRILLACTION;
	

	return statusMsg;
}

function mm(DPObj, PBID, DimFromID, DrillFilter, BID)
{
	var strSkin = '', strSkinSub = "IDItem ", strSkinSort= '',isDrill=(!DPObj || DPObj==null) ? false : true;
	// Check if interactive viewing enable
	if(isInteractive)
	{
		var nSort = -1, nFilter = -1;
		var sortAction = 'DISABLED';
		var arSortAction = new Array(null, null, null), arCalcAction=new Array(null,null,null,null,null,null);
		var bSortExist = true,bSortApplied = false,bRightCalcExist=('undefined' != typeof(actionTable[BID]))?((actionTable[BID].calc)?true:false):false, bBottomCalcExist=('undefined' != typeof(actionTable[BID]))?((actionTable[BID].bottomCalc)?true:false):false;		
		var bIVGraphExit=('undefined' != typeof(graphTable[BID]))?true:false;;
		var theAction = actionTable[BID];
		var bActionExist = (actionTable[BID] == null) ? false : true;
		if(bIVGraphExit)
		{
			var oname = new Array(graphTable[BID].vars.length);
			var oDuplicateID= new Array(graphTable[BID].vars.length);
		}
		if(!bActionExist || (theAction.sort==-1))
			bSortExist = false;
		else
		{
			for(var i = 0; i < arSortAction.length; i++)
				arSortAction[i] = new Action(true, 'sort', BID, null, null, null, null, null, i);
		}

		strSkin = "IVItem";
	}
	else
		strSkin = "IDItem";
	MenuList = new Array();
	SubMenuList = new Array();
	if(bSortExist)
		SortMenuList = new Array();
	if(isDrill)
	{
		var test=new Array(COUNT_DRILL);// array used to save and restore 1st submenu hierarchy (only for Drill By menu item
		var j=0,isubmenu=0;
		for(i=0;i<COUNT_DRILL;i++)
		{
			test[i]=new Array();
			switch(i)
			{
				case 0:	DrillObj=DPObj.dd;break;
				case 1:	DrillObj=DPObj.du;break;
				case 2:	DrillObj=DPObj.db;break;
				default:return;break;
			}

			if(!DrillObj) continue;

			// allocate submenu 
			var HierSave = -1;
			if(DrillObj.length>1)
			{
				for(ii=0;ii<DrillObj.length;ii++)
				{
					var SameHierOccurCount = 1;
					HierSave = DrillObj[ii][INDEX_HIERARCHYID];
					for(jj=ii+1;jj<DrillObj.length;jj++) // Loop to check count of same occurence of hierarchy ID
					{
						if(DrillObj[ii][INDEX_HIERARCHYID]==DrillObj[jj][INDEX_HIERARCHYID])
						{
							if(HierSave==DrillObj[jj][INDEX_HIERARCHYID])
							{
								SameHierOccurCount++;
								HierSave=DrillObj[ii][INDEX_HIERARCHYID];
							}
						}
					}
					if(SameHierOccurCount>1)
					{
						var len=SubMenuList.length;
						SubMenuList[len] = new Menu(DrillObj[ii][INDEX_HIERARCHYNAME]);
																				
						for(kk = ii; kk < ii + SameHierOccurCount; kk++)
						{
							var URLAction=MakeURL4MenuActionItem(true,DimFromID,BID,PBID,DrillObj[kk],-1,DrillFilter);
							SubMenuList[len].addMenuItem(DrillObj[kk][INDEX_DIMNAME],URLAction,null,null,null,DrillObj[kk],null,strSkinSub);
						}
						ii+=(SameHierOccurCount-1);
						test[i][test[i].length]=-1;
					}
					else test[i][test[i].length]= ii;
				}
			}
		}
		MenuList[0]=new Menu("");MenuList[1]=new Menu("");MenuList[2]=new Menu("");
	}
	if(isInteractive)
	{
		if(bIVGraphExit)
		{
			sortAction = null;
			for(var i = 0; i < arSortAction.length; i++)
				arSortAction[i] = new Action(true, 'sort', BID, null, null, null, null, null, i);

			ivAddMenu = new Menu(_LOC_ADD);
			ivReplaceMenu = new Menu(_LOC_REPLACE);
			ivRemoveMenu = new Menu(_LOC_REMOVE);
			ivarSortMenuList = new Array();

			for(var i=0;i<graphTable[BID].vars.length;i++)
			{
				if('undefined' != typeof(graphTable[BID].vars[i].name))
				{
					oname[i]=graphTable[BID].vars[i].name;
					// check dimension redundance
					for(j=0;j<graphTable[BID].vars.length;j++)
					if(graphTable[BID].vars[j].id == graphTable[BID].vars[i].id && i != j)
					{
						if('x' == graphTable[BID].vars[i].axis)	oname[i] +=' '+_LOC_XAXIS;
						else if('y' == graphTable[BID].vars[i].axis)	oname[i] +=' '+_LOC_YAXIS;
						else if('z' == graphTable[BID].vars[i].axis)	oname[i] +=' '+_LOC_ZAXIS;
						oDuplicateID[j] = 1;
					}
					else oDuplicateID[j] = 0;
					ivarSortMenuList[i] = new Menu(oname[i]);
				}
			}
		}
		SortMenuList = new Menu(_LOC_SORT_ITEM);
		// calculations
		if(bRightCalcExist && bBottomCalcExist)
		{
			calcRightMenuList = new Menu(_LOC_CALC_ATTHERIGHT);
			calcBottomMenuList = new Menu(_LOC_CALC_ATTHEBOTTOM);
			calcMenuList = new Menu(_LOC_CALCULATIONS);
			drillMenu = new Menu("CalcMenu");
		}
		else if(bRightCalcExist && !bBottomCalcExist){calcMenuList = new Menu(_LOC_CALCULATIONS);drillMenu = new Menu("CalcMenu");}

		if(bSortExist && !bIVGraphExit)
		{
			SortMenuList = new Menu(_LOC_SORT_ITEM);
			var aa = new Array;
			for(var i=0;i<arSortAction.length;i++)
			{
				var iva = new IVAction('sort',BID);
				iva.sort = arSortAction[i].SortValue;
				aa[i] = new Action(true,'sort',BID,null,null,null,null,null,null,iva);
			}
			MakeSortMenu(SortMenuList,theAction,aa);
			if(!bSortApplied)
			{
				strSkinSort = "IVItem IVSort_Default";
				strSkin = "IVItem IVSort_Default";
			}
		}
	}

	if(isDrill)
	{
		drillMenu = new Menu("DrillMenu");

		// second loop to build simple item whitout submenu
		var strItem = '', strItemLabel='';
		for(i = 0; i < COUNT_DRILL; i++)
		{
			var strItem = '', strItemLabel='';
			switch(i)
			{
				case 0:	DrillObj = DPObj.dd;strItem += _LOC_DRILLDOWNTO;strItemLabel += _LOC_DRILLDOWN;break;
				case 1:	DrillObj = DPObj.du;strItem += _LOC_DRILLUPTO;strItemLabel += _LOC_DRILLUP;break;
				case 2:	DrillObj = DPObj.db;strItem += _LOC_DRILLBY;strItemLabel = strItem;break;
				default:return;break;
			}
			MenuList[i].label = strItemLabel;
			if(!DrillObj)
				continue;
			var bAddSubMenu = false;
			if(DrillObj.length > 1)
			{
				subMenuAddedCount = 0;
				for(iii = 0; iii < test[i].length; iii++)
				{
					if(test[i][iii] != -1)// single menu item
					{
						var URLAction = MakeURL4MenuActionItem(true, DimFromID, BID, PBID, DrillObj[test[i][iii]], -1, DrillFilter);
						var stringItem = DrillObj[test[i][iii]][INDEX_HIERARCHYNAME];
						stringItem += _LOC_SEPARATOR_HIERARCHYNAME;
						stringItem += DrillObj[test[i][iii]][INDEX_DIMNAME];
						MenuList[i].addMenuItem(stringItem, URLAction, null, null, null, DrillObj[test[i][iii]], null, strSkinSub);
					}
					else // submenu item
					{
						if(subMenuAddedCount < SubMenuList.length)
						{
							MenuList[i].addMenuItem(SubMenuList[subMenuAddedCount], null, null, null, null, null, null, strSkinSub);
							subMenuAddedCount++;
						}
					}
				}
				if(test[i].length >= 1)	drillMenu.addMenuItem(MenuList[i], null, null, null, null, null, null, strSkin);
			}
			else if(DrillObj.length == 1)
			{
				delete MenuList[i];
				var URLAction = MakeURL4MenuActionItem(true, DimFromID, BID, PBID, DrillObj[0], -1, DrillFilter);
				strItem += DrillObj[0][INDEX_DIMNAME];
				if(DrillObj[0][INDEX_SCOPE] == 'out')
					strItem +=_LOC_NEWQUERY;
				drillMenu.addMenuItem(strItem, URLAction, null, null, null, DrillObj[0],null, strSkin);
			}
			else if(DrillObj.length ==  0 && i >= 0 && i <=2)
			{
				drillMenu.addMenuItem(strItemLabel, 'DISABLED', null, null, null, null, null, strSkin);
				delete MenuList[i];
			}
		}
	}
	else
	{
		drillMenu = new Menu("DrillMenu");
		drillMenu.addMenuItem(_LOC_DRILLDOWN, 'DISABLED', null, null, null, null, null, "IVItem");
		drillMenu.addMenuItem(_LOC_DRILLUP, 'DISABLED', null, null, null, null, null, "IVItem");
		drillMenu.addMenuItem(_LOC_DRILLBY, 'DISABLED', null, null, null, null, null, "IVItem");
	}
	// Add interactive Viewing features
	if(isInteractive)
	{
		if(bIVGraphExit)
		{
			MakeSubMenuGraph(BID,oname,oDuplicateID);
			drillMenu.addMenuItem(ivAddMenu, null, null, null, null, null, null, "IVItem IVSort_Default");
			drillMenu.addMenuItem(ivReplaceMenu, null, null, null, null, null, null, "IVItem IVSort_Default");
			drillMenu.addMenuItem(ivRemoveMenu, null, null, null, null, null, null, "IVItem IVRemove");
			drillMenu.addMenuItem(_LOC_TURNTO, new Action(true, 'turnto', BID, null, null, null, null, null, null,new IVAction('turnto',BID)), null, null, null, null, null, "IVItem");

		}
		else
		{
			if(0==actionTable[BID].addReplaceRemove)
			{
				drillMenu.addMenuItem(_LOC_ADD, new Action(true, 'add', BID, null, null, null, null, null, null,new IVAction('add',BID)), null, null, null, null, null, "IVItem IVSort_Default");
				drillMenu.addMenuItem(_LOC_REPLACE, new Action(true, 'replace', BID, null, null, null, null, null, null,new IVAction('replace',BID)),null, null, null, null, null, "IVItem IVSort_Default");		
				drillMenu.addMenuItem(_LOC_REMOVE, new Action(true, 'remove', BID, null, null, null, null, null, null,new IVAction('remove',BID)), null, null, null, null, null, "IVItem IVRemove");	
			}
			else
			{
				drillMenu.addMenuItem(_LOC_ADD,'DISABLED',null,null,null,null,null,"IVItem");
				drillMenu.addMenuItem(_LOC_REPLACE,'DISABLED',null,null,null,null,null,"IVItem");
				drillMenu.addMenuItem(_LOC_REMOVE,'DISABLED',null,null,null,null,null,"IVItem IVRemove_dis");
			}
			if(0==actionTable[BID].setAsSection)
				drillMenu.addMenuItem(_LOC_SETASSECTION, new Action(true,'setAsSection',BID,null,null,null,null,null,null,new IVAction('setAsSection',BID)),null,null,null,null,null,"IVItem");
			else if(-1==actionTable[BID].setAsSection)
				drillMenu.addMenuItem(_LOC_SETASSECTION,'DISABLED',null,null,null,null,null,"IVItem");
			if(0==actionTable[BID].swap)
				drillMenu.addMenuItem(_LOC_SWAPAXIS,new Action(true,'swap',BID,null,null,null,null,null,null,new IVAction('swap',BID)),null,null,null,null,null,"IVItem IVSwapAxis");
			else if(-1==actionTable[BID].swap)
				drillMenu.addMenuItem(_LOC_SWAPAXIS,'DISABLED',null,null,null,null,null,"IVItem IVSwapAxis_dis");
			if(0==actionTable[BID].turnTo)
				drillMenu.addMenuItem(_LOC_TURNTO, new Action(true, 'turnto', BID, null, null, null, null, null, null,new IVAction('turnto',BID)), null, null, null, null, null, "IVItem");
			else if(-1==actionTable[BID].turnTo)
				drillMenu.addMenuItem(_LOC_TURNTO, 'DISABLED', null, null, null, null, null, "IVItem");

			drillMenu.addMenuItem(_LOC_FORMATCELL, new Action(true, 'formatCell', BID, null, null, null, null, null, null,new IVAction('formatCell',BID)), null, null, null, null, null, "IVItem");
		}
		if(bIVGraphExit)
		{
			for(var i=0;i<ivarSortMenuList.length;i++)
			{
				MakeSortMenu4Graph(ivarSortMenuList[i],graphTable[BID].vars,i,BID);
			}
			
			for(var i=0;i<ivarSortMenuList.length;i++)
			{
				strSkinSort = "IVItem ";
				if(0==graphTable[BID].vars[i].qualif) strSkinSort +="IVDimension";
				else if(1==graphTable[BID].vars[i].qualif) strSkinSort +="IVDetail";
				else if(2==graphTable[BID].vars[i].qualif) strSkinSort +="IVMeasure";
				SortMenuList.addMenuItem(ivarSortMenuList[i], null, null, null, null, null, null, strSkinSort);
			}
			drillMenu.addMenuItem(SortMenuList,null,null,null,null,null,null,"IVItem");
		}
		else if(bSortExist)
			drillMenu.addMenuItem(SortMenuList, null, null, null, null, null, null, strSkinSort);
		else
			drillMenu.addMenuItem(_LOC_SORT_ITEM,'DISABLED',null,null,null,null,null,"IVItem IVSort_Default");

		// calculations
		if(bBottomCalcExist) // At the right
		{
			MakeSubMenuCalc(calcRightMenuList, actionTable[BID].calc, BID, 0);
			MakeSubMenuCalc(calcBottomMenuList, actionTable[BID].bottomCalc, BID,1);
			calcMenuList.addMenuItem(calcRightMenuList, null, null, null, null, null, null, "IVItem IVCalcRight");
			calcMenuList.addMenuItem(calcBottomMenuList, null, null, null, null, null, null, "IVItem IVCalcBottom");
			drillMenu.addMenuItem(calcMenuList, null, null, null, null, null, null, "IVItem IVCalc");
		}
				
		if(bRightCalcExist && !bBottomCalcExist)
		{
			MakeSubMenuCalc(calcMenuList, actionTable[BID].calc, BID,0);
			drillMenu.addMenuItem(calcMenuList, null, null, null, null, null, null, "IVItem IVCalc");
		}
	}
	drillMenu.writeMenus();
	showMenu(drillMenu);
}

function GetHierarchyCount(DrillObj)
{
	var len = DrillObj.length;
	var count = 0;
	if(len <= 1)
		return len;
	
	DrillObjByHierID = new Array();
	for(i = 0; i < len - 1; i++)
	{
		if(DrillObj[i][INDEX_HIERARCHYID] != DrillObj[i + 1][INDEX_HIERARCHYID])
			count++;
	}
	return count;
}
function GetDrillObjByHier(DrillAr, HierID)
{
	for(i = 0; i < DrillAr.length; i++)
	{
		if(DrillAr[i][INDEX_HIERARCHYID] == HierID)
			return DrillAr[i];
	}
}

function MakeSubMenuGraph(BID,oname,oDuplicateID)
{
	if(0==graphTable[BID].x)
	{
		var a = new IVAction('add',BID);a.axis = 'x';
		ivAddMenu.addMenuItem(_LOC_ONXAXIS, new Action(true,'add',BID,null,null,null,null,null,null,a), null, null, null, null, null, "IVItem IVSort_Default");
	}
	if(0==graphTable[BID].y)
	{
		var a = new IVAction('add',BID);a.axis = 'y';
		ivAddMenu.addMenuItem(_LOC_ONYAXIS, new Action(true,'add',BID,null,null,null,null,null,null,a), null, null, null, null, null, "IVItem IVSort_Default");
	}
	if(0==graphTable[BID].z)
	{
		var a = new IVAction('add',BID);
		a.axis = 'z';
		ivAddMenu.addMenuItem(_LOC_ONZAXIS, new Action(true,'add',BID,null,null,null,null,null,null,a), null, null, null, null, null, "IVItem IVSort_Default");
	}
	var axisindex=0;
	for(var i=0;i<graphTable[BID].vars.length;i++)
	{
		if('undefined' != typeof(graphTable[BID].vars))
		{
			var a = new IVAction('replace',BID);a.id=graphTable[BID].vars[i].id;a.axis = graphTable[BID].vars[i].axis;
			if(i>0 && graphTable[BID].vars[i-1].axis == graphTable[BID].vars[i].axis)++axisindex;
			else axisindex=0;
			a.axisIndex = axisindex;
			strSkinSort = "IVItem ";if(0==graphTable[BID].vars[i].qualif) strSkinSort +="IVDimension";else if(1==graphTable[BID].vars[i].qualif) strSkinSort +="IVDetail";else if(2==graphTable[BID].vars[i].qualif) strSkinSort +="IVMeasure";
			ivReplaceMenu.addMenuItem(oname[i], new Action(true,'replace',BID,null,null,null,null,null,null,a), null, null, null, null, null, strSkinSort);
		}
	}
	axisindex=0;
	for(var i=0;i<graphTable[BID].vars.length;i++)
	{
		if('undefined' != typeof(graphTable[BID].vars))
		{
			var a = new IVAction('remove',BID);a.id=graphTable[BID].vars[i].id;a.axis = graphTable[BID].vars[i].axis;
			if(i>0 && graphTable[BID].vars[i-1].axis == graphTable[BID].vars[i].axis) ++axisindex;
			else axisindex=0;
			a.axisIndex=axisindex;
			strSkinSort = "IVItem ";if(0==graphTable[BID].vars[i].qualif) strSkinSort +="IVDimension";else if(1==graphTable[BID].vars[i].qualif) strSkinSort +="IVDetail";else if(2==graphTable[BID].vars[i].qualif) strSkinSort +="IVMeasure";
			ivRemoveMenu.addMenuItem(oname[i], new Action(true,'replace',BID,null,null,null,null,null,null,a), null, null, null, null, null, strSkinSort);
		}
	}
	axisindex=0;
/*	for(var i=0;i<graphTable[BID].vars.length;i++)
	{
		if(('undefined' != typeof(graphTable[BID].vars)) && graphTable[BID].vars[i].filter != -1)
		{
			var a = new IVAction('filter',BID);a.id = graphTable[BID].vars[i].id;a.axis = graphTable[BID].vars[i].axis;
			if(i>0 && graphTable[BID].vars[i-1].axis == graphTable[BID].vars[i].axis) ++axisindex;
			else axisindex=0;
			a.axisIndex=axisindex;
			strSkinSort = "IVItem ";if(0==graphTable[BID].vars[i].qualif) strSkinSort +="IVDimension";else if(1==graphTable[BID].vars[i].qualif) strSkinSort +="IVDetail";else if(2==graphTable[BID].vars[i].qualif) strSkinSort +="IVMeasure";
			//if(oDuplicateID[i] != 1)
			ivFilterMenu.addMenuItem(graphTable[BID].vars[i].name, new Action(true,'filter',BID,null,null,null,null,null,null,a), null, null, null, null, null, strSkinSort);
		}
	}*/
}

function MakeSubMenuCalc(calcMenu, calcTable, BID, bottom)
{
	var calcSkin;
	var calcValue;
	if(-1 == calcTable.sum){ calcSkin = 'IVItem IVCalcSum_dis';calcValue = 'DISABLED';}
	else
	{
		calcSkin = (1 == calcTable.sum) ? 'IVItem IVCalcSum_sel' : 'IVItem IVCalcSum';
		calcValue = new Action(true, 'calc', BID, null, null, null, null, null, null,new IVAction('calc',BID,bottom));calcValue.IVAction.calc = 'sum';
	}
	calcMenu.addMenuItem(_LOC_CALC_SUM, calcValue, null, null, null, null, null, calcSkin);
	
	if(-1 == calcTable.count){ calcSkin = 'IVItem IVCalcCount_dis';calcValue = 'DISABLED';}
	else
	{
		calcSkin = (1 == calcTable.count) ? 'IVItem IVCalcCount_sel' : 'IVItem IVCalcCount';
		calcValue = new Action(true, 'calc', BID, null, null, null, null, null, null,new IVAction('calc',BID,bottom));calcValue.IVAction.calc = 'count';
	}
	calcMenu.addMenuItem(_LOC_CALC_COUNT, calcValue, null, null, null, null, null, calcSkin);
	calcValue = (-1 == calcTable.avg) ? 'DISABLED' : (0 == calcTable.avg)? new Action(true, 'calc', BID, null, null, null, null, null, null,new IVAction('calc',BID,bottom)) : undefined;
	
	if(-1 == calcTable.avg){ calcSkin = 'IVItem IVCalcAvg_dis';calcValue = 'DISABLED';}
	else
	{
		calcSkin = (1 == calcTable.avg) ? 'IVItem IVCalcAvg_sel' : 'IVItem IVCalcAvg';
		calcValue = new Action(true, 'calc', BID, null, null, null, null, null, null,new IVAction('calc',BID,bottom));calcValue.IVAction.calc = 'avg';
	}
	calcMenu.addMenuItem(_LOC_CALC_AVERAGE, calcValue, null, null, null, null, null, calcSkin);
	if(-1 == calcTable.min){ calcSkin = 'IVItem IVCalcAvg_dis';calcValue = 'DISABLED';}
	else
	{
		calcSkin = (1 == calcTable.min) ? 'IVItem IVCalcMin_sel' : 'IVItem IVCalcMin';
		calcValue = new Action(true, 'calc', BID, null, null, null, null, null, null,new IVAction('calc',BID,bottom));calcValue.IVAction.calc = 'min';
	}
	calcMenu.addMenuItem(_LOC_CALC_MIN, calcValue, null, null, null, null, null, calcSkin);
	if(-1 == calcTable.max){ calcSkin = 'IVItem IVCalcMax_dis';calcValue = 'DISABLED';}
	else
	{
		calcSkin = (1 == calcTable.max) ? 'IVItem IVCalcMax_sel' : 'IVItem IVCalcMax';
		calcValue = new Action(true, 'calc', BID, null, null, null, null, null, null,new IVAction('calc',BID,bottom));calcValue.IVAction.calc = 'max';
	}
	calcMenu.addMenuItem(_LOC_CALC_MAX, calcValue, null, null, null, null, null, calcSkin);

	if(-1 == calcTable.percent){ calcSkin = 'IVItem IVCalcPercent_dis';calcValue = 'DISABLED';}
	else
	{
		calcSkin = (1 == calcTable.percent) ? 'IVItem IVCalcPercent_sel' : 'IVItem IVCalcPercent';
		calcValue = new Action(true, 'calc', BID, null, null, null, null, null, null,new IVAction('calc',BID,bottom));calcValue.IVAction.calc = 'percent';
	}
	calcMenu.addMenuItem(_LOC_CALC_PERCENTAGE, calcValue, null, null, null, null, null, calcSkin);
}

function MakeSortMenu(sortMenu, theAction, ivarAction)
{
	if(theAction.sort == 0)
		sortMenu.addMenuItem(_LOC_SORTDEFAULT,'DISABLED',null,null,null,null,null,"IVItem IVSort_Default_sel");
	else
		sortMenu.addMenuItem(_LOC_SORTDEFAULT,ivarAction[0],null,null,null,null,null,"IVItem IVSort_Default");
		

	if(theAction.sort == 1)
	{
		bSortApplied = true;
		sortMenu.addMenuItem(_LOC_SORTASCENDING,'DISABLED',null,null,null,null,null,"IVItem IVSort_Ascending_sel");
	}
	else
		sortMenu.addMenuItem(_LOC_SORTASCENDING,ivarAction[1],null,null,null,null,null,"IVItem IVSort_Ascending");
		
	if(theAction.sort == 2)
	{
		bSortApplied = true;
		sortMenu.addMenuItem(_LOC_SORTDESCENDING,'DISABLED',null,null,null,null,null,"IVItem IVSort_Descending_sel");
	}
	else 
		sortMenu.addMenuItem(_LOC_SORTDESCENDING,ivarAction[2],null,null,null,null,null,"IVItem IVSort_Descending");
}

function MakeSortMenu4Graph(sortMenu,gtv,index, bid)
{
	var strSkin='', strSkinSort='';
	var a = gtv[index];
	var actionVal;
	var iv = new IVAction('sort', bid, null);
	var aa = new Array;
	for(var i=0;i<3;i++) aa[i] = new Action(true,'sort',bid,null,null,null,null,null,null,null);
	
	if(gtv[index].sort == 0)
	{
		strSkin = "IVItem IVSort_Default_sel";
		actionVal = 'DISABLED';
	}
	else
	{
		strSkin = "IVItem IVSort_Default";
		actionVal = aa[0];
	}
	
	if(index>0 && gtv[index-1].axis == gtv[index].axis) ++iv.axisIndex;
	iv.sort=0;iv.axis=gtv[index].axis;
	aa[0].IVAction=iv;

	sortMenu.addMenuItem(_LOC_SORTDEFAULT, actionVal, null, null, null, null, null, strSkin);

	if(gtv[index].sort == 1)
	{
		strSkin = "IVItem IVSort_Ascending_sel";
		strSkinSort = "IVItem IVSort_Ascending";
		bSortApplied = true;
		actionVal = 'DISABLED';
	}
	else
	{
		strSkin = "IVItem IVSort_Ascending";
		actionVal = aa[1];
	}

	iv = new IVAction('sort', bid, null);
	if(index>0 && gtv[index-1].axis == gtv[index].axis) ++iv.axisIndex;
	iv.sort=1;iv.axis=gtv[index].axis;
	aa[1].IVAction = iv;
	sortMenu.addMenuItem(_LOC_SORTASCENDING, actionVal, null, null, null, null, null, strSkin);
		
	if(gtv[index].sort == 2)
	{
		strSkin = "IVItem IVSort_Descending_sel";
		strSkinSort = "IVItem IVSort_Descending";
		bSortApplied = true;
		actionVal = 'DISABLED';
	}
	else
	{
		strSkin = "IVItem IVSort_Descending";
		actionVal = aa[2];
	}
	iv = new IVAction('sort', bid, null);
	if(index>0 && gtv[index-1].axis == gtv[index].axis) ++iv.axisIndex;
	iv.sort=2;iv.axis=gtv[index].axis;
	aa[2].IVAction = iv;
	sortMenu.addMenuItem(_LOC_SORTDESCENDING, actionVal, null, null, null, null, null, strSkin);
}

function ActionDesc(sort, filter,calc,bottomCalc,swap,setAsSection,addReplaceRemove,turnTo){var o=this;o.sort=sort;o.filter=filter;o.calc=calc;o.bottomCalc=bottomCalc;o.swap=swap;o.setAsSection=setAsSection;o.addReplaceRemove=addReplaceRemove;o.turnTo=turnTo;}
function calcDesc(sum,count,avg,min,max,percent){var o=this;o.sum=sum;o.count=count;o.avg=avg;o.min=min;o.max=max;o.percent=percent;}
function graphVar(name,id,axis,sort,filter,qualif){var o=this;o.name=name;o.id=id;o.axis=axis;o.sort=sort;o.filter=filter;o.qualif=qualif;}
function graphDesc(vars,x,y,z,swap,setAsSection){var o=this;o.vars=vars;o.x=x;o.y=y;o.z=z;o.swap=swap,o.setAsSection=setAsSection;}
function InteractiveAction(){var o=this;o.reason=null;o.bid=null;o.sort=null;o.calc=null;o.bottomCalc=null;o.id=null;o.axis=null;o.axisIndex=0;}
function IVAction(reason, bid,bottom){var o=this;o.reason=reason;o.bid=bid;o.sort=null;o.calc=null;o.bottomCalc=bottom;o.id=null;o.axis=null;o.axisIndex=0;}
function InteractiveAction(a){var o=this;o.reason=a.reason;o.bid=a.bid;o.sort=a.sort;o.calc=a.calc;o.bottomCalc=a.bottomCalc;o.id=a.id;o.axis=a.axis;o.axisIndex=a.axisIndex;}
//-->