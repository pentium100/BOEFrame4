//Default browsercheck, added to all scripts!
function checkBrowser()
{
	navigator.version	= 0;
	
	this.ver=navigator.appVersion
	this.dom=document.getElementById?1:0
	var i=0;
	var ua = window.navigator.userAgent.toLowerCase();
	
	if ((i = ua.indexOf('msie')) != -1)
	{
		navigator.version	= parseFloat('0' + ua.substr(i+5), 10);
		
		this.ie3x=(navigator.version <= 4) ? 1:0;
		this.ie5x=(navigator.version > 4) ? 1:0;
		this.ie6x=(navigator.version >= 6) ? 1:0;
		this.saf=(ua.indexOf('safari') !=-1)?1:0;
	}
	else if ((ua.indexOf('mozilla') !=-1) && (ua.indexOf('spoofer')==-1) && (ua.indexOf('compatible') == -1) && (ua.indexOf('opera')==-1)&& (ua.indexOf('webtv')==-1) && (ua.indexOf('hotjava')==-1))
	{
		this.ns5=(this.dom && parseInt(this.ver) >= 5) ?1:0;
		this.ns4=(document.layers && !this.dom)?1:0;
		this.saf=(ua.indexOf('safari') !=-1)?1:0;
		
	}
	this.bw = (this.ie3x || this.ie5x || this.ns5 || this.ns4 || this.saf);
}