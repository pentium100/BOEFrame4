<!--
//---------------------------------------------------------------------
// Global variables
//---------------------------------------------------------------------
var idTimer = -1;
var gHoverElement;
var gActionPending = false;

function sc (element, bShow)
{
	var	strCursor;
	if (bShow)
	{
		if (bw.ie6x || bw.ns5)
			strCursor="pointer";
		else if (bw.ie5x)
			strCursor="hand";
	}
	else
		strCursor="default";
	element.style.cursor=strCursor;
	if(bw.saf != 1)
		element.title = _LOC_TOOLTIP;

}


function cm(element, BID)
{
	if(gActionPending == true)return;

	if("undefined" != typeof(element))
	{
		sc (element, true);
		gHoverElement = element;
	}
	gBIDWihtDrillOnFocus = BID;
	if(bw.saf)
		idTimer = window.setTimeout("mm(" + 'gHoverElement' + "," + 'gBIDWihtDrillOnFocus' + ")", 700);
	else	
		mm(gHoverElement,BID);
}

function hm(){clearTimeout(idTimer);}

if(document.captureEvents){document.captureEvents(Event.MOUSEMOVE|Event.MOUSEUP);}

function sm(DP_ID, DrillType){return "Test";}

function mm(element, BID)
{
	var nSort = -1, nFilter = -1;
	var sortAction = 'DISABLED', filterAction = 'DISABLED';
	var arSortAction = new Array(null, null, null), arCalcAction=new Array(null,null,null,null,null,null);
	var bSortExist = true, bSortApplied = false, bRightCalcExist=('undefined' != typeof(actionTable[BID]))?((actionTable[BID].calc)?true:false):false, bBottomCalcExist=('undefined' != typeof(actionTable[BID]))?((actionTable[BID].bottomCalc)?true:false):false;
	var bIVGraphExit=('undefined' != typeof(graphTable[BID]))?true:false;
	var theAction = (!bIVGraphExit) ? actionTable[BID] : new ActionDesc(graphTable[BID].sort,graphTable[BID].filter,null,null);
	var bActionExist = (actionTable[BID] == null) ? false : true;
	var strSkinSort;
	if(bIVGraphExit)
	{
		var oname = new Array(graphTable[BID].vars.length);
		var oDuplicateID= new Array(graphTable[BID].vars.length);
	}

	if("undefined" != gHoverElement)
		sc (gHoverElement, false);
	gHoverElement = null;

	if(!bActionExist || (theAction.sort==-1)) 
		bSortExist = false;
	else
	{
		sortAction = null;
		for(var i = 0; i < arSortAction.length; i++)
			arSortAction[i] = new Action(true, 'sort', BID, null, null, null, null, null, i);
	}
	filterAction = (!bActionExist || (theAction.filter==-1)) ? 'DISABLED' : new Action(true, 'filter', BID, null, null, null, null, null);
	
	// IV for Graph
	if(bIVGraphExit)
	{
		sortAction = null;
		for(var i = 0; i < arSortAction.length; i++)
			arSortAction[i] = new Action(true, 'sort', BID, null, null, null, null, null, i);
			
		ivChartAddMenu = new Menu(_LOC_ADD);
		ivChartReplaceMenu = new Menu(_LOC_REPLACE);
		ivChartRemoveMenu = new Menu(_LOC_REMOVE);
		ivChartFilterMenu = new Menu(_LOC_FILTERBY_PPP_ITEM);
		ivarChartSortMenuList = new Array();
		for(var i=0;i<graphTable[BID].vars.length;i++)
		{
			if('undefined' != typeof(graphTable[BID].vars[i].name))
			{
				oname[i]=graphTable[BID].vars[i].name;
				// check dimension redundance
				for(j=0;j<graphTable[BID].vars.length;j++)
				if(graphTable[BID].vars[j].id == graphTable[BID].vars[i].id && i != j)
				{
					if('x' == graphTable[BID].vars[i].axis)	oname[i] +=' '+_LOC_XAXIS;
					else if('y' == graphTable[BID].vars[i].axis)	oname[i] +=' '+_LOC_YAXIS;
					else if('z' == graphTable[BID].vars[i].axis)	oname[i] +=' '+_LOC_ZAXIS;
					oDuplicateID[j] = 1;
				}
				else oDuplicateID[j] = 0;
				ivarChartSortMenuList[i] = new Menu(oname[i]);
			}
		}
		SortMenuList = new Menu(_LOC_SORT_ITEM);
	}
	// calculations
	if(bRightCalcExist && bBottomCalcExist)
	{
		calcRightMenuList = new Menu(_LOC_CALC_ATTHERIGHT);
		calcBottomMenuList = new Menu(_LOC_CALC_ATTHEBOTTOM);
		calcMenuList = new Menu(_LOC_CALCULATIONS);
		ivMenu = new Menu("CalcMenu");
	}
	else if(bRightCalcExist && !bBottomCalcExist){calcMenuList = new Menu(_LOC_CALCULATIONS);ivMenu = new Menu("CalcMenu");}
	if(bSortExist && !bIVGraphExit)
	{
		SortMenuList = new Menu(_LOC_SORT_ITEM);
		ivMenu = new Menu("ivMenu");
		var aa = new Array;
		for(var i=0;i<arSortAction.length;i++)
		{
			var iva = new IVAction('sort',BID);
			iva.sort = arSortAction[i].SortValue;
			aa[i] = new Action(true,'sort',BID,null,null,null,null,null,null,iva);
		}
		MakeSortMenu(SortMenuList,theAction,aa);
		if(!bSortApplied)
		{
			strSkinSort = "IVItem IVSort_Default";
			strSkin = "IVItem IVSort_Default";
		}
	}	
	else
		window.ivMenu = new Menu("ivMenu");

	strSkin = ('DISABLED' == filterAction) ? "IVItem IVFilter_Disabled" : "IVItem IVFilter_Default";

	if(bIVGraphExit)
	{
		MakeSubMenuGraph(BID,oname,oDuplicateID);
		ivMenu.addMenuItem(ivChartAddMenu,null,null,null,null,null,null,"IVItem");
		ivMenu.addMenuItem(ivChartReplaceMenu,null,null,null,null,null,null,"IVItem");
		ivMenu.addMenuItem(ivChartRemoveMenu,null,null,null, null,null,null,"IVItem IVRemove");
		
/*		if(0==graphTable[BID].setAsSection)
			ivMenu.addMenuItem(_LOC_SETASSECTION, new Action(true,'setAsSection',BID,null,null,null,null,null,null,new IVAction('setAsSection',BID)),null,null,null,null,null,"IVItem");
		else if(-1==graphTable[BID].setAsSection)
			ivMenu.addMenuItem(_LOC_SETASSECTION,'DISABLED',null,null,null,null,null,"IVItem");
*/
		if(0==graphTable[BID].swap)
			ivMenu.addMenuItem(_LOC_SWAPAXIS,new Action(true,'swap',BID,null,null,null,null,null,null,new IVAction('swap',BID)),null,null,null,null,null,"IVItem IVSwapAxis");
		else if(-1==graphTable[BID].swap)
			ivMenu.addMenuItem(_LOC_SWAPAXIS,'DISABLED',null,null,null,null,null,"IVItem IVSwapAxis_dis");
		ivMenu.addMenuItem(ivChartFilterMenu,null,null,null, null,null,null,"IVItem IVFilter_Default");
		ivMenu.addMenuItem(_LOC_TURNTO, new Action(true, 'turnto', BID, null, null, null, null, null, null,new IVAction('turnto',BID)), null, null, null, null, null, "IVItem");
	}
	else
	{
		if(0==actionTable[BID].addReplaceRemove)
		{
			ivMenu.addMenuItem(_LOC_ADD,new Action(true,'add',BID,null,null,null,null,null,null,new IVAction('add',BID)),null,null,null,null,null,"IVItem");
			ivMenu.addMenuItem(_LOC_REPLACE,new Action(true,'replace',BID,null,null,null,null,null,null,new IVAction('replace',BID)),null,null,null,null,null,"IVItem");
			ivMenu.addMenuItem(_LOC_REMOVE,new Action(true,'remove',BID,null,null,null,null,null,null,new IVAction('remove',BID)),null,null,null,null,null,"IVItem IVRemove");
		}
		else
		{
			ivMenu.addMenuItem(_LOC_ADD,'DISABLED',null,null,null,null,null,"IVItem");
			ivMenu.addMenuItem(_LOC_REPLACE,'DISABLED',null,null,null,null,null,"IVItem");
			ivMenu.addMenuItem(_LOC_REMOVE,'DISABLED',null,null,null,null,null,"IVItem IVRemove_dis");
		}
		if(0==actionTable[BID].setAsSection)
			ivMenu.addMenuItem(_LOC_SETASSECTION, new Action(true,'setAsSection',BID,null,null,null,null,null,null,new IVAction('setAsSection',BID)),null,null,null,null,null,"IVItem");
		else if(-1==actionTable[BID].setAsSection)
			ivMenu.addMenuItem(_LOC_SETASSECTION,'DISABLED',null,null,null,null,null,"IVItem");
		if(0==actionTable[BID].swap)
			ivMenu.addMenuItem(_LOC_SWAPAXIS,new Action(true,'swap',BID,null,null,null,null,null,null,new IVAction('swap',BID)),null,null,null,null,null,"IVItem IVSwapAxis");
		else if(-1==actionTable[BID].swap)
			ivMenu.addMenuItem(_LOC_SWAPAXIS,'DISABLED',null,null,null,null,null,"IVItem IVSwapAxis_dis");
		if(0==actionTable[BID].turnTo)
			ivMenu.addMenuItem(_LOC_TURNTO, new Action(true, 'turnto', BID, null, null, null, null, null, null,new IVAction('turnto',BID)), null, null, null, null, null, "IVItem");
		else if(-1==actionTable[BID].swap)
			ivMenu.addMenuItem(_LOC_TURNTO, 'DISABLED', null, null, null, null, null, "IVItem");

		ivMenu.addMenuItem(_LOC_FORMATCELL, new Action(true, 'formatCell', BID, null, null, null, null, null, null,new IVAction('formatCell',BID)), null, null, null, null, null, "IVItem");
	}
	if(!bIVGraphExit)
	{
		var a;
		if('DISABLED' != filterAction) a = new Action(true, 'filter', BID, null, null, null, null, null, null,new IVAction('filter',BID))
		else a = filterAction;
		ivMenu.addMenuItem(_LOC_FILTERBY_PPP_ITEM, a, null, null, null, null, null, strSkin);
	}
	if(bSortExist) 
		ivMenu.addMenuItem(SortMenuList, null, null, null, null, null, null, strSkinSort);
	else if(bIVGraphExit)
	{
		for(var i=0;i<ivarChartSortMenuList.length;i++)
		{
			MakeSortMenu4Graph(ivarChartSortMenuList[i],graphTable[BID].vars,i,BID);
		}
		
		for(var i=0;i<ivarChartSortMenuList.length;i++)
		{
			strSkinSort = "IVItem ";
			if(0==graphTable[BID].vars[i].qualif) strSkinSort +="IVDimension";
			else if(1==graphTable[BID].vars[i].qualif) strSkinSort +="IVDetail";
			else if(2==graphTable[BID].vars[i].qualif) strSkinSort +="IVMeasure";
			SortMenuList.addMenuItem(ivarChartSortMenuList[i], null, null, null, null, null, null, strSkinSort);
		}
		ivMenu.addMenuItem(SortMenuList,null,null,null,null,null,null,"IVItem");
	}
	else ivMenu.addMenuItem(_LOC_SORT_ITEM, 'DISABLED', null, null, null, null, null, "IVItem IVSort_Default");
	
	// calculations
	if(bBottomCalcExist) // At the right
	{
		MakeSubMenuCalc(calcRightMenuList, actionTable[BID].calc, BID, 0);
		MakeSubMenuCalc(calcBottomMenuList, actionTable[BID].bottomCalc, BID,1);
		calcMenuList.addMenuItem(calcRightMenuList, null, null, null, null, null, null, "IVItem IVCalcRight");
		calcMenuList.addMenuItem(calcBottomMenuList, null, null, null, null, null, null, "IVItem IVCalcBottom");
		ivMenu.addMenuItem(calcMenuList, null, null, null, null, null, null, "IVItem IVCalc");
	}
			
	if(bRightCalcExist && !bBottomCalcExist)
	{
		MakeSubMenuCalc(calcMenuList, actionTable[BID].calc, BID,0);
		ivMenu.addMenuItem(calcMenuList, null, null, null, null, null, null, "IVItem IVCalc");
	}
	
	ivMenu.writeMenus();
	showMenu(window.ivMenu);
}

function MakeSubMenuCalc(calcMenu, calcTable, BID, bottom)
{
	var calcSkin;
	var calcValue;
	if(-1 == calcTable.sum){ calcSkin = 'IVItem IVCalcSum_dis';calcValue = 'DISABLED';}
	else
	{
		calcSkin = (1 == calcTable.sum) ? 'IVItem IVCalcSum_sel' : 'IVItem IVCalcSum';
		calcValue = new Action(true, 'calc', BID, null, null, null, null, null, null,new IVAction('calc',BID,bottom));calcValue.IVAction.calc = 'sum';
	}
	calcMenu.addMenuItem(_LOC_CALC_SUM, calcValue, null, null, null, null, null, calcSkin);
	
	if(-1 == calcTable.count){ calcSkin = 'IVItem IVCalcCount_dis';calcValue = 'DISABLED';}
	else
	{
		calcSkin = (1 == calcTable.count) ? 'IVItem IVCalcCount_sel' : 'IVItem IVCalcCount';
		calcValue = new Action(true, 'calc', BID, null, null, null, null, null, null,new IVAction('calc',BID,bottom));calcValue.IVAction.calc = 'count';
	}
	calcMenu.addMenuItem(_LOC_CALC_COUNT, calcValue, null, null, null, null, null, calcSkin);
	calcValue = (-1 == calcTable.avg) ? 'DISABLED' : (0 == calcTable.avg)? new Action(true, 'calc', BID, null, null, null, null, null, null,new IVAction('calc',BID,bottom)) : undefined;
	
	if(-1 == calcTable.avg){ calcSkin = 'IVItem IVCalcAvg_dis';calcValue = 'DISABLED';}
	else
	{
		calcSkin = (1 == calcTable.avg) ? 'IVItem IVCalcAvg_sel' : 'IVItem IVCalcAvg';
		calcValue = new Action(true, 'calc', BID, null, null, null, null, null, null,new IVAction('calc',BID,bottom));calcValue.IVAction.calc = 'avg';
	}
	calcMenu.addMenuItem(_LOC_CALC_AVERAGE, calcValue, null, null, null, null, null, calcSkin);
	if(-1 == calcTable.min){ calcSkin = 'IVItem IVCalcAvg_dis';calcValue = 'DISABLED';}
	else
	{
		calcSkin = (1 == calcTable.min) ? 'IVItem IVCalcMin_sel' : 'IVItem IVCalcMin';
		calcValue = new Action(true, 'calc', BID, null, null, null, null, null, null,new IVAction('calc',BID,bottom));calcValue.IVAction.calc = 'min';
	}
	calcMenu.addMenuItem(_LOC_CALC_MIN, calcValue, null, null, null, null, null, calcSkin);
	if(-1 == calcTable.max){ calcSkin = 'IVItem IVCalcMax_dis';calcValue = 'DISABLED';}
	else
	{
		calcSkin = (1 == calcTable.max) ? 'IVItem IVCalcMax_sel' : 'IVItem IVCalcMax';
		calcValue = new Action(true, 'calc', BID, null, null, null, null, null, null,new IVAction('calc',BID,bottom));calcValue.IVAction.calc = 'max';
	}
	calcMenu.addMenuItem(_LOC_CALC_MAX, calcValue, null, null, null, null, null, calcSkin);

	if(-1 == calcTable.percent){ calcSkin = 'IVItem IVCalcPercent_dis';calcValue = 'DISABLED';}
	else
	{
		calcSkin = (1 == calcTable.percent) ? 'IVItem IVCalcPercent_sel' : 'IVItem IVCalcPercent';
		calcValue = new Action(true, 'calc', BID, null, null, null, null, null, null,new IVAction('calc',BID,bottom));calcValue.IVAction.calc = 'percent';
	}
	calcMenu.addMenuItem(_LOC_CALC_PERCENTAGE, calcValue, null, null, null, null, null, calcSkin);
}

function MakeSubMenuGraph(BID,oname,oDuplicateID)
{
	if(0==graphTable[BID].x)
	{
		var a = new IVAction('add',BID);a.axis = 'x';
		ivChartAddMenu.addMenuItem(_LOC_ONXAXIS, new Action(true,'add',BID,null,null,null,null,null,null,a), null, null, null, null, null, "IVItem IVSort_Default");
	}
	if(0==graphTable[BID].y)
	{
		var a = new IVAction('add',BID);a.axis = 'y';
		ivChartAddMenu.addMenuItem(_LOC_ONYAXIS, new Action(true,'add',BID,null,null,null,null,null,null,a), null, null, null, null, null, "IVItem IVSort_Default");
	}
	if(0==graphTable[BID].z)
	{
		var a = new IVAction('add',BID);
		a.axis = 'z';
		ivChartAddMenu.addMenuItem(_LOC_ONZAXIS, new Action(true,'add',BID,null,null,null,null,null,null,a), null, null, null, null, null, "IVItem IVSort_Default");
	}
	var axisindex=0;
	for(var i=0;i<graphTable[BID].vars.length;i++)
	{
		if('undefined' != typeof(graphTable[BID].vars))
		{
			var a = new IVAction('replace',BID);a.id=graphTable[BID].vars[i].id;a.axis = graphTable[BID].vars[i].axis;
			if(i>0 && graphTable[BID].vars[i-1].axis == graphTable[BID].vars[i].axis)++axisindex;
			else axisindex=0;
			a.axisIndex = axisindex;
			strSkinSort = "IVItem ";if(0==graphTable[BID].vars[i].qualif) strSkinSort +="IVDimension";else if(1==graphTable[BID].vars[i].qualif) strSkinSort +="IVDetail";else if(2==graphTable[BID].vars[i].qualif) strSkinSort +="IVMeasure";
			ivChartReplaceMenu.addMenuItem(oname[i], new Action(true,'replace',BID,null,null,null,null,null,null,a), null, null, null, null, null, strSkinSort);
		}
	}
	axisindex=0;
	for(var i=0;i<graphTable[BID].vars.length;i++)
	{
		if('undefined' != typeof(graphTable[BID].vars))
		{
			var a = new IVAction('remove',BID);a.id=graphTable[BID].vars[i].id;a.axis = graphTable[BID].vars[i].axis;
			if(i>0 && graphTable[BID].vars[i-1].axis == graphTable[BID].vars[i].axis) ++axisindex;
			else axisindex=0;
			a.axisIndex=axisindex;
			strSkinSort = "IVItem ";if(0==graphTable[BID].vars[i].qualif) strSkinSort +="IVDimension";else if(1==graphTable[BID].vars[i].qualif) strSkinSort +="IVDetail";else if(2==graphTable[BID].vars[i].qualif) strSkinSort +="IVMeasure";
			ivChartRemoveMenu.addMenuItem(oname[i], new Action(true,'replace',BID,null,null,null,null,null,null,a), null, null, null, null, null, strSkinSort);
		}
	}
	axisindex=0;
	for(var i=0;i<graphTable[BID].vars.length;i++)
	{
		if(('undefined' != typeof(graphTable[BID].vars)) && graphTable[BID].vars[i].filter != -1)
		{
			var a = new IVAction('filter',BID);a.id = graphTable[BID].vars[i].id;a.axis = graphTable[BID].vars[i].axis;
			if(i>0 && graphTable[BID].vars[i-1].axis == graphTable[BID].vars[i].axis) ++axisindex;
			else axisindex=0;
			a.axisIndex=axisindex;
			strSkinSort = "IVItem ";if(0==graphTable[BID].vars[i].qualif) strSkinSort +="IVDimension";else if(1==graphTable[BID].vars[i].qualif) strSkinSort +="IVDetail";else if(2==graphTable[BID].vars[i].qualif) strSkinSort +="IVMeasure";
			//if(oDuplicateID[i] != 1)
			ivChartFilterMenu.addMenuItem(graphTable[BID].vars[i].name, new Action(true,'filter',BID,null,null,null,null,null,null,a), null, null, null, null, null, strSkinSort);
		}
	}
}
function MakeSortMenu(sortMenu, theAction, ivarAction)
{
	if(theAction.sort == 0)
		sortMenu.addMenuItem(_LOC_SORTDEFAULT,'DISABLED',null,null,null,null,null,"IVItem IVSort_Default_sel");
	else
		sortMenu.addMenuItem(_LOC_SORTDEFAULT,ivarAction[0],null,null,null,null,null,"IVItem IVSort_Default");
		

	if(theAction.sort == 1)
	{
		bSortApplied = true;
		sortMenu.addMenuItem(_LOC_SORTASCENDING,'DISABLED',null,null,null,null,null,"IVItem IVSort_Ascending_sel");
	}
	else
		sortMenu.addMenuItem(_LOC_SORTASCENDING,ivarAction[1],null,null,null,null,null,"IVItem IVSort_Ascending");
		
	if(theAction.sort == 2)
	{
		bSortApplied = true;
		sortMenu.addMenuItem(_LOC_SORTDESCENDING,'DISABLED',null,null,null,null,null,"IVItem IVSort_Descending_sel");
	}
	else 
		sortMenu.addMenuItem(_LOC_SORTDESCENDING,ivarAction[2],null,null,null,null,null,"IVItem IVSort_Descending");
}

function MakeSortMenu4Graph(sortMenu,gtv,index, bid)
{
	var strSkin='', strSkinSort='';
	var a = gtv[index];
	var actionVal;
	var iv = new IVAction('sort', bid, null);
	var aa = new Array;
	for(var i=0;i<3;i++) aa[i] = new Action(true,'sort',bid,null,null,null,null,null,null,null);
	
	if(gtv[index].sort == 0)
	{
		strSkin = "IVItem IVSort_Default_sel";
		actionVal = 'DISABLED';
	}
	else
	{
		strSkin = "IVItem IVSort_Default";
		actionVal = aa[0];
	}
	
	if(index>0 && gtv[index-1].axis == gtv[index].axis) ++iv.axisIndex;
	iv.sort=0;iv.axis=gtv[index].axis;
	aa[0].IVAction=iv;

	sortMenu.addMenuItem(_LOC_SORTDEFAULT, actionVal, null, null, null, null, null, strSkin);

	if(gtv[index].sort == 1)
	{
		strSkin = "IVItem IVSort_Ascending_sel";
		strSkinSort = "IVItem IVSort_Ascending";
		bSortApplied = true;
		actionVal = 'DISABLED';
	}
	else
	{
		strSkin = "IVItem IVSort_Ascending";
		actionVal = aa[1];
	}

	iv = new IVAction('sort', bid, null);
	if(index>0 && gtv[index-1].axis == gtv[index].axis) ++iv.axisIndex;
	iv.sort=1;iv.axis=gtv[index].axis;
	aa[1].IVAction = iv;
	sortMenu.addMenuItem(_LOC_SORTASCENDING, actionVal, null, null, null, null, null, strSkin);
		
	if(gtv[index].sort == 2)
	{
		strSkin = "IVItem IVSort_Descending_sel";
		strSkinSort = "IVItem IVSort_Descending";
		bSortApplied = true;
		actionVal = 'DISABLED';
	}
	else
	{
		strSkin = "IVItem IVSort_Descending";
		actionVal = aa[2];
	}
	iv = new IVAction('sort', bid, null);
	if(index>0 && gtv[index-1].axis == gtv[index].axis) ++iv.axisIndex;
	iv.sort=2;iv.axis=gtv[index].axis;
	aa[2].IVAction = iv;
	sortMenu.addMenuItem(_LOC_SORTDESCENDING, actionVal, null, null, null, null, null, strSkin);
}

function ActionDesc(sort, filter,calc,bottomCalc,swap,setAsSection,addReplaceRemove,turnTo){var o=this;o.sort=sort;o.filter=filter;o.calc=calc;o.bottomCalc=bottomCalc;o.swap=swap;o.setAsSection=setAsSection;o.addReplaceRemove=addReplaceRemove;o.turnTo=turnTo;}
function calcDesc(sum,count,avg,min,max,percent){var o=this;o.sum=sum;o.count=count;o.avg=avg;o.min=min;o.max=max;o.percent=percent;}
function graphVar(name,id,axis,sort,filter,qualif){var o=this;o.name=name;o.id=id;o.axis=axis;o.sort=sort;o.filter=filter;o.qualif=qualif;}
function graphDesc(vars,x,y,z,swap,setAsSection){	var o=this;o.vars=vars;o.x=x;o.y=y;o.z=z;o.swap=swap,o.setAsSection=setAsSection;}
function InteractiveAction(){var o=this;o.reason=null;o.bid=null;o.sort=null;o.calc=null;o.bottomCalc=null;o.id=null;o.axis=null;o.axisIndex=0;}
function IVAction(reason, bid,bottom){var o=this;o.reason=reason;o.bid=bid;o.sort=null;o.calc=null;o.bottomCalc=bottom;o.id=null;o.axis=null;o.axisIndex=0;}
function InteractiveAction(a){var o=this;o.reason=a.reason;o.bid=a.bid;o.sort=a.sort;o.calc=a.calc;o.bottomCalc=a.bottomCalc;o.id=a.id;o.axis=a.axis;o.axisIndex=a.axisIndex;}

function GenerateURL(action)
{
	gActionPending = true;
	applyInteractiveViewing(new InteractiveAction(action.IVAction));
}
//-->