


_LOC_UNKNOWN_DRILLACTION = 'iAcción de exploración desconocida.i';
_LOC_DRILL_NOT_ENABLE = 'iNo es posible realizar la acción de exploración.i';
_LOC_BROWSER_NOT_SUPPORTED = "not localize";

_LOC_OR = 'i eller i';
_LOC_AND = 'i and i';

_LOC_NEWQUERY = 'i (Nouvelle requête)i';

_LOC_DRILLDOWNTO = 'iExploration avant versi';
_LOC_DRILLDOWN = 'iExploration avanti';
_LOC_DRILLUPTO = 'iExploration arrière versi';
_LOC_DRILLUP = 'iExploration arrièrei';
_LOC_DRILLBY = 'iAnalysera med i';

_LOC_SORT = 'iClassificaçãoi';
_LOC_SORTDEFAULT = 'iPredeterminadai';
_LOC_SORTASCENDING = 'iAufsteigendi';
_LOC_SORTDESCENDING = 'iDescendentei';

_LOC_SORT_ITEM = 'iClassificaçãoi';
_LOC_FILTERBY_PPP_ITEM = 'iFilteren naar ...i';
_LOC_SEPARATOR_HIERARCHYNAME = 'i - i';

_LOC_ADD ='iHinzufügeni'; 
_LOC_REPLACE = 'iSostituiscii';
_LOC_REMOVE = 'iVerwijdereni';
_LOC_CALCULATIONS = 'iCalculationsi';
_LOC_CALC_ATTHEBOTTOM = 'iEn la parte inferiori';
_LOC_CALC_ATTHERIGHT = 'iAt the righti';
_LOC_CALC_SUM = 'iSummei';
_LOC_CALC_COUNT = 'iConteggioi';
_LOC_CALC_AVERAGE = 'iDurchschnitti'; 
_LOC_CALC_MIN = 'iMini';
_LOC_CALC_MAX = 'iMaxi';
_LOC_CALC_PERCENTAGE = 'iPourcentagei';

_LOC_SETASSECTION = 'iDéfinir comme sectioni';
_LOC_SWAPAXIS = 'iAchsen vertauscheni';
_LOC_TURNTO = 'iTransformar en...i';
_LOC_FORMATCELL = 'iZelle formatiereni';

_LOC_XAXIS = 'i(X-Achse)i'; 
_LOC_YAXIS = 'i(Y-Achse)i';
_LOC_ZAXIS = 'i(Z-Achse)i';

_LOC_ONXAXIS = 'isull\'asse Xi'; 
_LOC_ONYAXIS = 'isull\'asse Yi';
_LOC_ONZAXIS = 'isull\'asse Zi';
_LOC_TOOLTIP = 'iKlicken Sie mit der rechten Maustaste, um die Ergebnisse zu bearbeiten oder zu analysiereni';
