


_LOC_UNKNOWN_DRILLACTION = 'Ukjent analysehandling.';
_LOC_DRILL_NOT_ENABLE = 'Analysehandlingen er ikke mulig.';
_LOC_BROWSER_NOT_SUPPORTED = "not localize";

_LOC_OR = 'eller';
_LOC_AND = ' og';

_LOC_NEWQUERY = ' (Ny spørring)';

_LOC_DRILLDOWNTO = 'Analyser ned til';
_LOC_DRILLDOWN = 'Analyser ned';
_LOC_DRILLUPTO = 'Analyser opp til';
_LOC_DRILLUP = 'Analyser opp';
_LOC_DRILLBY = 'Analyser etter';

_LOC_SORT = 'Sortering';
_LOC_SORTDEFAULT = 'Standard';
_LOC_SORTASCENDING = 'Stigende';
_LOC_SORTDESCENDING = 'Synkende';

_LOC_SORT_ITEM = 'Sortering';
_LOC_FILTERBY_PPP_ITEM = 'Filtrer etter...';
_LOC_SEPARATOR_HIERARCHYNAME = ' - ';

_LOC_ADD ='Legg til'; 
_LOC_REPLACE = 'Erstatt';
_LOC_REMOVE = 'Fjern';
_LOC_CALCULATIONS = 'Beregninger';
_LOC_CALC_ATTHEBOTTOM = 'På bunnen';
_LOC_CALC_ATTHERIGHT = 'Til høyre';
_LOC_CALC_SUM = 'Sum';
_LOC_CALC_COUNT = 'Antall';
_LOC_CALC_AVERAGE = 'Gjennomsnitt'; 
_LOC_CALC_MIN = 'Min';
_LOC_CALC_MAX = 'Maks';
_LOC_CALC_PERCENTAGE = 'Prosent';

_LOC_SETASSECTION = 'Angi som avsnitt';
_LOC_SWAPAXIS = 'Bytt akser';
_LOC_TURNTO = 'Gå til...';
_LOC_FORMATCELL = 'Formater celle';

_LOC_XAXIS = '(X-aksen)'; 
_LOC_YAXIS = '(Y-aksen)';
_LOC_ZAXIS = '(Z-aksen)';

_LOC_ONXAXIS = 'på X-aksen'; 
_LOC_ONYAXIS = 'på Y-aksen';
_LOC_ONZAXIS = 'på Z-aksen';
_LOC_TOOLTIP = 'Høyreklikk hvis du vil redigere eller analysere disse resultatene';
