


_LOC_UNKNOWN_DRILLACTION = 'Onbekende analysebewerking.';
_LOC_DRILL_NOT_ENABLE = 'Analysebewerking kan niet worden uitgevoerd.';
_LOC_BROWSER_NOT_SUPPORTED = "not localize";

_LOC_OR = ' of';
_LOC_AND = ' en';

_LOC_NEWQUERY = ' (Nieuwe query)';

_LOC_DRILLDOWNTO = 'Niveau omlaag naar';
_LOC_DRILLDOWN = 'Niveau omlaag';
_LOC_DRILLUPTO = 'Niveau omhoog naar';
_LOC_DRILLUP = 'Niveau omhoog';
_LOC_DRILLBY = 'Analyseren op';

_LOC_SORT = 'Sorteren';
_LOC_SORTDEFAULT = 'Standaard';
_LOC_SORTASCENDING = 'Oplopend';
_LOC_SORTDESCENDING = 'Aflopend';

_LOC_SORT_ITEM = 'Sorteren';
_LOC_FILTERBY_PPP_ITEM = 'Filteren naar ...';
_LOC_SEPARATOR_HIERARCHYNAME = ' - ';

_LOC_ADD ='Toevoegen'; 
_LOC_REPLACE = 'Vervangen';
_LOC_REMOVE = 'Verwijderen';
_LOC_CALCULATIONS = 'Berekeningen';
_LOC_CALC_ATTHEBOTTOM = 'Onderaan';
_LOC_CALC_ATTHERIGHT = 'Rechts';
_LOC_CALC_SUM = 'Som';
_LOC_CALC_COUNT = 'Aantal';
_LOC_CALC_AVERAGE = 'Gemiddelde'; 
_LOC_CALC_MIN = 'Min';
_LOC_CALC_MAX = 'Max';
_LOC_CALC_PERCENTAGE = 'Percentage';

_LOC_SETASSECTION = 'Sectie instellen';
_LOC_SWAPAXIS = 'Assen verwisselen';
_LOC_TURNTO = 'Omzetten in...';
_LOC_FORMATCELL = 'Cel opmaken';

_LOC_XAXIS = '(x-as)'; 
_LOC_YAXIS = '(y-as)';
_LOC_ZAXIS = '(z-as)';

_LOC_ONXAXIS = 'op X-as'; 
_LOC_ONYAXIS = 'op y-as';
_LOC_ONZAXIS = 'op z-as';
_LOC_TOOLTIP = 'Klik met de rechtermuisknop om deze resultaten te bewerken of te analyseren';
