


_LOC_UNKNOWN_DRILLACTION = 'Unknown drill action.';
_LOC_DRILL_NOT_ENABLE = 'Drill action is not possible.';
_LOC_BROWSER_NOT_SUPPORTED = "not localize";

_LOC_OR = ' or ';
_LOC_AND = ' and ';

_LOC_NEWQUERY = ' (New Query)';

_LOC_DRILLDOWNTO = 'Drill Down to ';
_LOC_DRILLDOWN = 'Drill Down ';
_LOC_DRILLUPTO = 'Drill Up to ';
_LOC_DRILLUP = 'Drill Up ';
_LOC_DRILLBY = 'Drill By ';

_LOC_SORT = 'Sort ';
_LOC_SORTDEFAULT = 'Default ';
_LOC_SORTASCENDING = 'Ascending';
_LOC_SORTDESCENDING = 'Descending';

_LOC_SORT_ITEM = 'Sort ';
_LOC_FILTERBY_PPP_ITEM = 'Filter by ...';
_LOC_SEPARATOR_HIERARCHYNAME = ' - ';

_LOC_ADD ='Add'; 
_LOC_REPLACE = 'Replace';
_LOC_REMOVE = 'Remove';
_LOC_CALCULATIONS = 'Calculations';
_LOC_CALC_ATTHEBOTTOM = 'At the bottom';
_LOC_CALC_ATTHERIGHT = 'At the right';
_LOC_CALC_SUM = 'Sum';
_LOC_CALC_COUNT = 'Count';
_LOC_CALC_AVERAGE = 'Average'; 
_LOC_CALC_MIN = 'Min';
_LOC_CALC_MAX = 'Max';
_LOC_CALC_PERCENTAGE = 'Percentage';

_LOC_SETASSECTION = 'Set as section';
_LOC_SWAPAXIS = 'Swap axes';
_LOC_TURNTO = 'Turn to...';
_LOC_FORMATCELL = 'Format cell';

_LOC_XAXIS = '(X-Axis)'; 
_LOC_YAXIS = '(Y-Axis)';
_LOC_ZAXIS = '(Z-Axis)';

_LOC_ONXAXIS = 'on X-Axis'; 
_LOC_ONYAXIS = 'on Y-Axis';
_LOC_ONZAXIS = 'on Z-Axis';
_LOC_TOOLTIP = 'Right-click to edit or analyze these results';
