


_LOC_UNKNOWN_DRILLACTION = 'Okänd analysåtgärd.';
_LOC_DRILL_NOT_ENABLE = 'Analysåtgärd kan inte utföras.';
_LOC_BROWSER_NOT_SUPPORTED = "not localize";

_LOC_OR = ' eller ';
_LOC_AND = ' och ';

_LOC_NEWQUERY = ' (Ny fråga)';

_LOC_DRILLDOWNTO = 'Analysera ned till ';
_LOC_DRILLDOWN = 'Analysera ned ';
_LOC_DRILLUPTO = 'Analysera upp till ';
_LOC_DRILLUP = 'Analysera upp ';
_LOC_DRILLBY = 'Analysera med ';

_LOC_SORT = 'Sortera ';
_LOC_SORTDEFAULT = 'Standard ';
_LOC_SORTASCENDING = 'Stigande';
_LOC_SORTDESCENDING = 'Fallande';

_LOC_SORT_ITEM = 'Sortera ';
_LOC_FILTERBY_PPP_ITEM = 'Filtrera efter...';
_LOC_SEPARATOR_HIERARCHYNAME = ' - ';

_LOC_ADD ='Lägg till'; 
_LOC_REPLACE = 'Ersätt';
_LOC_REMOVE = 'Ta bort';
_LOC_CALCULATIONS = 'Beräkningar';
_LOC_CALC_ATTHEBOTTOM = 'Längst ned';
_LOC_CALC_ATTHERIGHT = 'Till höger';
_LOC_CALC_SUM = 'Summa';
_LOC_CALC_COUNT = 'Antal';
_LOC_CALC_AVERAGE = 'Medelvärde'; 
_LOC_CALC_MIN = 'Min';
_LOC_CALC_MAX = 'Max';
_LOC_CALC_PERCENTAGE = 'Procent';

_LOC_SETASSECTION = 'Ange som avsnitt';
_LOC_SWAPAXIS = 'Växla axlar';
_LOC_TURNTO = 'Växla till...';
_LOC_FORMATCELL = 'Formatera cell';

_LOC_XAXIS = '(X-axel)'; 
_LOC_YAXIS = '(Y-axel)';
_LOC_ZAXIS = '(Z-axel)';

_LOC_ONXAXIS = 'på X-axeln'; 
_LOC_ONYAXIS = 'på Y-axel';
_LOC_ONZAXIS = 'på Z-axel';
_LOC_TOOLTIP = 'Högerklicka för att redigera eller analysera dessa resultat';
