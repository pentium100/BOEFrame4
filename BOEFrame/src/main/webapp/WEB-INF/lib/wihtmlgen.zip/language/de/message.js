


_LOC_UNKNOWN_DRILLACTION = 'Unbekannter Drill-Vorgang.';
_LOC_DRILL_NOT_ENABLE = 'Drill-Vorgang nicht möglich.';
_LOC_BROWSER_NOT_SUPPORTED = "not localize";

_LOC_OR = ' oder';
_LOC_AND = ' und';

_LOC_NEWQUERY = ' (Neue Abfrage)';

_LOC_DRILLDOWNTO = 'Drilldown zu';
_LOC_DRILLDOWN = 'Drilldown';
_LOC_DRILLUPTO = 'Drillup zu';
_LOC_DRILLUP = 'Drillup';
_LOC_DRILLBY = 'Objekt-Drill';

_LOC_SORT = 'Sortierung';
_LOC_SORTDEFAULT = 'Standard';
_LOC_SORTASCENDING = 'Aufsteigend';
_LOC_SORTDESCENDING = 'Absteigend';

_LOC_SORT_ITEM = 'Sortierung';
_LOC_FILTERBY_PPP_ITEM = 'Filtern nach ...';
_LOC_SEPARATOR_HIERARCHYNAME = ' -';

_LOC_ADD ='Hinzufügen'; 
_LOC_REPLACE = 'Ersetzen';
_LOC_REMOVE = 'Entfernen';
_LOC_CALCULATIONS = 'Berechnungen';
_LOC_CALC_ATTHEBOTTOM = 'Unten';
_LOC_CALC_ATTHERIGHT = 'Rechts';
_LOC_CALC_SUM = 'Summe';
_LOC_CALC_COUNT = 'Anzahl';
_LOC_CALC_AVERAGE = 'Durchschnitt'; 
_LOC_CALC_MIN = 'Min';
_LOC_CALC_MAX = 'Max';
_LOC_CALC_PERCENTAGE = 'Prozent';

_LOC_SETASSECTION = 'Sektion erstellen';
_LOC_SWAPAXIS = 'Achsen vertauschen';
_LOC_TURNTO = 'Umwandeln in...';
_LOC_FORMATCELL = 'Zelle formatieren';

_LOC_XAXIS = '(X-Achse)'; 
_LOC_YAXIS = '(Y-Achse)';
_LOC_ZAXIS = '(Z-Achse)';

_LOC_ONXAXIS = 'Auf X-Achse'; 
_LOC_ONYAXIS = 'Auf Y-Achse';
_LOC_ONZAXIS = 'Auf Z-Achse';
_LOC_TOOLTIP = 'Klicken Sie mit der rechten Maustaste, um die Ergebnisse zu bearbeiten oder zu analysieren';
