


_LOC_UNKNOWN_DRILLACTION = 'การดูข้อมูลเพิ่มเติมที่ไม่รู้';
_LOC_DRILL_NOT_ENABLE = 'ดูข้อมูลเพิ่มเติมไม่ได้';
_LOC_BROWSER_NOT_SUPPORTED = "not localize";

_LOC_OR = 'or';
_LOC_AND = 'and';

_LOC_NEWQUERY = ' (การสืบค้นใหม่)';

_LOC_DRILLDOWNTO = 'ดูข้อมูลเชิงลึกที่';
_LOC_DRILLDOWN = 'ดูข้อมูลเชิงลึก';
_LOC_DRILLUPTO = 'ดูข้อมูลโดยรวมที่';
_LOC_DRILLUP = 'ดูข้อมูลโดยรวม';
_LOC_DRILLBY = 'ดูข้อมูลเพิ่มเติม';

_LOC_SORT = 'การเรียง';
_LOC_SORTDEFAULT = 'ดีฟอลต์';
_LOC_SORTASCENDING = 'เรียงลำดับจากน้อยไปหามาก';
_LOC_SORTDESCENDING = 'เรียงลำดับจากมากไปหาน้อย';

_LOC_SORT_ITEM = 'การเรียง';
_LOC_FILTERBY_PPP_ITEM = 'กลั่นกรองตาม ...';
_LOC_SEPARATOR_HIERARCHYNAME = ' - ';

_LOC_ADD ='เพิ่ม'; 
_LOC_REPLACE = 'แทนที่';
_LOC_REMOVE = 'ลบ';
_LOC_CALCULATIONS = 'การคำนวณ';
_LOC_CALC_ATTHEBOTTOM = 'ด้านล่างสุด';
_LOC_CALC_ATTHERIGHT = 'ทางขวา';
_LOC_CALC_SUM = 'ผลรวม';
_LOC_CALC_COUNT = 'การนับ';
_LOC_CALC_AVERAGE = 'ค่าเฉลี่ย'; 
_LOC_CALC_MIN = 'ต่ำสุด';
_LOC_CALC_MAX = 'สูงสุด';
_LOC_CALC_PERCENTAGE = 'เปอร์เซ็นต์';

_LOC_SETASSECTION = 'ตั้งค่าเป็นส่วน';
_LOC_SWAPAXIS = 'แกนสลับ';
_LOC_TURNTO = 'เปลี่ยนเป็น...';
_LOC_FORMATCELL = 'จัดรูปแบบเซลล์';

_LOC_XAXIS = '(แกน X)'; 
_LOC_YAXIS = '(แกน Y)';
_LOC_ZAXIS = '(แกน Z)';

_LOC_ONXAXIS = 'บนแกน X'; 
_LOC_ONYAXIS = 'บนแกน Y';
_LOC_ONZAXIS = 'บนแกน Z';
_LOC_TOOLTIP = 'คลิกขวาเพื่อแก้ไขหรือวิเคราะห์ผลลัพธ์เหล่านี้';
