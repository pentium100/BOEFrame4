


_LOC_UNKNOWN_DRILLACTION = '未知的往下鑽取動作。';
_LOC_DRILL_NOT_ENABLE = '鑽取動作無法進行。';
_LOC_BROWSER_NOT_SUPPORTED = "not localize";

_LOC_OR = ' 或';
_LOC_AND = ' 與';

_LOC_NEWQUERY = ' (新查詢)';

_LOC_DRILLDOWNTO = '往下鑽取至';
_LOC_DRILLDOWN = '往下鑽取';
_LOC_DRILLUPTO = '往上鑽取至';
_LOC_DRILLUP = '往上鑽取';
_LOC_DRILLBY = '鑽取依據';

_LOC_SORT = '排序';
_LOC_SORTDEFAULT = '預設';
_LOC_SORTASCENDING = '遞增';
_LOC_SORTDESCENDING = '遞減';

_LOC_SORT_ITEM = '排序';
_LOC_FILTERBY_PPP_ITEM = '篩選依據 ...';
_LOC_SEPARATOR_HIERARCHYNAME = ' -';

_LOC_ADD ='新增'; 
_LOC_REPLACE = '置換';
_LOC_REMOVE = '移除';
_LOC_CALCULATIONS = '計算';
_LOC_CALC_ATTHEBOTTOM = '在底部';
_LOC_CALC_ATTHERIGHT = '在右邊';
_LOC_CALC_SUM = '總和';
_LOC_CALC_COUNT = '計數';
_LOC_CALC_AVERAGE = '平均值'; 
_LOC_CALC_MIN = '最小值';
_LOC_CALC_MAX = '最大值';
_LOC_CALC_PERCENTAGE = '百分比';

_LOC_SETASSECTION = '設定為區段';
_LOC_SWAPAXIS = '交換座標軸';
_LOC_TURNTO = '轉至...';
_LOC_FORMATCELL = '格式化儲存格';

_LOC_XAXIS = '(X 座標軸)'; 
_LOC_YAXIS = '(Y 座標軸)';
_LOC_ZAXIS = '(Z 座標軸)';

_LOC_ONXAXIS = '在 X 座標軸'; 
_LOC_ONYAXIS = '在 Y 座標軸';
_LOC_ONZAXIS = '在 Z 座標軸';
_LOC_TOOLTIP = '按一下右鍵以編輯或分析結果';
