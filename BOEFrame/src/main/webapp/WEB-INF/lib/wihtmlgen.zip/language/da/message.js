


_LOC_UNKNOWN_DRILLACTION = 'Ukendt analysehandling.';
_LOC_DRILL_NOT_ENABLE = 'Analysehandlingen er ikke mulig.';
_LOC_BROWSER_NOT_SUPPORTED = "not localize";

_LOC_OR = ' eller ';
_LOC_AND = 'og';

_LOC_NEWQUERY = ' (Ny forespørgsel)';

_LOC_DRILLDOWNTO = 'Analyser faldende til';
_LOC_DRILLDOWN = 'Analyser faldende';
_LOC_DRILLUPTO = 'Analyser stigende til';
_LOC_DRILLUP = 'Analyser stigende';
_LOC_DRILLBY = 'Analyser ved hjælp af';

_LOC_SORT = 'Sorter';
_LOC_SORTDEFAULT = 'Standard';
_LOC_SORTASCENDING = 'Stigende';
_LOC_SORTDESCENDING = 'Faldende';

_LOC_SORT_ITEM = 'Sorter';
_LOC_FILTERBY_PPP_ITEM = 'Filtrer ved hjælp af ...';
_LOC_SEPARATOR_HIERARCHYNAME = ' - ';

_LOC_ADD ='Tilføj'; 
_LOC_REPLACE = 'Replace';
_LOC_REMOVE = 'Fjern';
_LOC_CALCULATIONS = 'Beregninger';
_LOC_CALC_ATTHEBOTTOM = 'Nederst';
_LOC_CALC_ATTHERIGHT = 'Til højre';
_LOC_CALC_SUM = 'Sum';
_LOC_CALC_COUNT = 'Antal';
_LOC_CALC_AVERAGE = 'Gennemsnit'; 
_LOC_CALC_MIN = 'Min';
_LOC_CALC_MAX = 'Max';
_LOC_CALC_PERCENTAGE = 'Percentage';

_LOC_SETASSECTION = 'Angiv som handling';
_LOC_SWAPAXIS = 'Ombyt akser';
_LOC_TURNTO = 'Skift til...';
_LOC_FORMATCELL = 'Formater celle';

_LOC_XAXIS = '(X-akse)'; 
_LOC_YAXIS = '(Y-akse)';
_LOC_ZAXIS = '(Z-akse)';

_LOC_ONXAXIS = 'på x-akse'; 
_LOC_ONYAXIS = 'på y-akse';
_LOC_ONZAXIS = 'på z-akse';
_LOC_TOOLTIP = 'Højreklik for at redigere eller analysere resultaterne';
