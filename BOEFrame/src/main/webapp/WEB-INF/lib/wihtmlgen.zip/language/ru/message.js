


_LOC_UNKNOWN_DRILLACTION = 'Неизвестное действие перехода по иерархии.';
_LOC_DRILL_NOT_ENABLE = 'Невозможно выполнить действие перехода по иерархии.';
_LOC_BROWSER_NOT_SUPPORTED = "not localize";

_LOC_OR = ' или ';
_LOC_AND = ' и ';

_LOC_NEWQUERY = ' (Новый запрос)';

_LOC_DRILLDOWNTO = 'Детализация до ';
_LOC_DRILLDOWN = 'Детализация ';
_LOC_DRILLUPTO = 'Переход по иерархии вверх к ';
_LOC_DRILLUP = 'Обобщение ';
_LOC_DRILLBY = 'Детализовать ';

_LOC_SORT = 'Сортировка ';
_LOC_SORTDEFAULT = 'По умолчанию ';
_LOC_SORTASCENDING = 'По возрастанию';
_LOC_SORTDESCENDING = 'По убыванию';

_LOC_SORT_ITEM = 'Сортировка ';
_LOC_FILTERBY_PPP_ITEM = 'Фильтровать по ...';
_LOC_SEPARATOR_HIERARCHYNAME = ' - ';

_LOC_ADD ='Добавить'; 
_LOC_REPLACE = 'Replace';
_LOC_REMOVE = 'Удалить';
_LOC_CALCULATIONS = 'Вычисления';
_LOC_CALC_ATTHEBOTTOM = 'Внизу';
_LOC_CALC_ATTHERIGHT = 'Справа';
_LOC_CALC_SUM = 'Сумма';
_LOC_CALC_COUNT = 'Количество';
_LOC_CALC_AVERAGE = 'Среднее'; 
_LOC_CALC_MIN = 'Мин';
_LOC_CALC_MAX = 'Макс';
_LOC_CALC_PERCENTAGE = 'Процент';

_LOC_SETASSECTION = 'Задать как раздел';
_LOC_SWAPAXIS = 'Поменять местами оси';
_LOC_TURNTO = 'Преобразовать в...';
_LOC_FORMATCELL = 'Форматировать ячейку';

_LOC_XAXIS = '(Ось X)'; 
_LOC_YAXIS = '(Ось Y)';
_LOC_ZAXIS = '(Ось Z)';

_LOC_ONXAXIS = 'на оси X'; 
_LOC_ONYAXIS = 'на оси Y';
_LOC_ONZAXIS = 'на оси Z';
_LOC_TOOLTIP = 'Для редактирования или анализа этих результатов щелкните правой кнопкой мыши';
