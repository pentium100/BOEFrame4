


_LOC_UNKNOWN_DRILLACTION = '알 수 없는 드릴 작업입니다.';
_LOC_DRILL_NOT_ENABLE = '드릴 작업을 수행할 수 없습니다.';
_LOC_BROWSER_NOT_SUPPORTED = "not localize";

_LOC_OR = ' 또는';
_LOC_AND = ' 및';

_LOC_NEWQUERY = ' (새 쿼리)';

_LOC_DRILLDOWNTO = '드릴다운';
_LOC_DRILLDOWN = '드릴다운';
_LOC_DRILLUPTO = '드릴업';
_LOC_DRILLUP = '드릴업';
_LOC_DRILLBY = '드릴 기준';

_LOC_SORT = '정렬';
_LOC_SORTDEFAULT = '기본값';
_LOC_SORTASCENDING = '오름차순';
_LOC_SORTDESCENDING = '내림차순';

_LOC_SORT_ITEM = '정렬';
_LOC_FILTERBY_PPP_ITEM = '필터링 기준...';
_LOC_SEPARATOR_HIERARCHYNAME = ' -';

_LOC_ADD ='추가'; 
_LOC_REPLACE = '바꾸기';
_LOC_REMOVE = '제거';
_LOC_CALCULATIONS = '계산';
_LOC_CALC_ATTHEBOTTOM = '맨 아래로';
_LOC_CALC_ATTHERIGHT = '오른쪽으로';
_LOC_CALC_SUM = '합계';
_LOC_CALC_COUNT = '개수';
_LOC_CALC_AVERAGE = '평균'; 
_LOC_CALC_MIN = '최소';
_LOC_CALC_MAX = '최대';
_LOC_CALC_PERCENTAGE = '백분율';

_LOC_SETASSECTION = '섹션으로 설정';
_LOC_SWAPAXIS = '축 바꾸기';
_LOC_TURNTO = '변환...';
_LOC_FORMATCELL = '셀 서식';

_LOC_XAXIS = '(X-축)'; 
_LOC_YAXIS = '(Y-축)';
_LOC_ZAXIS = '(Z-축)';

_LOC_ONXAXIS = 'X-축'; 
_LOC_ONYAXIS = 'Y-축';
_LOC_ONZAXIS = 'Z-축';
_LOC_TOOLTIP = '이 결과를 편집하거나 분석하려면 마우스 오른쪽 단추를 클릭하십시오.';
