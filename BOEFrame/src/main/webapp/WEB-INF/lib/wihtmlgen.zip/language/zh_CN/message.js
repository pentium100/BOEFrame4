


_LOC_UNKNOWN_DRILLACTION = '未知的钻取操作。';
_LOC_DRILL_NOT_ENABLE = '不可能进行钻取操作。';
_LOC_BROWSER_NOT_SUPPORTED = "not localize";

_LOC_OR = ' 或';
_LOC_AND = ' 和';

_LOC_NEWQUERY = ' （新查询）';

_LOC_DRILLDOWNTO = '向下钻取到';
_LOC_DRILLDOWN = '向下钻取';
_LOC_DRILLUPTO = '向上钻取到';
_LOC_DRILLUP = '向上钻取';
_LOC_DRILLBY = '钻取依据';

_LOC_SORT = '排序';
_LOC_SORTDEFAULT = '缺省值';
_LOC_SORTASCENDING = '升序';
_LOC_SORTDESCENDING = '降序';

_LOC_SORT_ITEM = '排序';
_LOC_FILTERBY_PPP_ITEM = '过滤者 ...';
_LOC_SEPARATOR_HIERARCHYNAME = ' -';

_LOC_ADD ='添加'; 
_LOC_REPLACE = '替换';
_LOC_REMOVE = '除去';
_LOC_CALCULATIONS = '计算';
_LOC_CALC_ATTHEBOTTOM = '在底部';
_LOC_CALC_ATTHERIGHT = '在右侧';
_LOC_CALC_SUM = '总和';
_LOC_CALC_COUNT = '计数';
_LOC_CALC_AVERAGE = '平均值'; 
_LOC_CALC_MIN = '最小值';
_LOC_CALC_MAX = '最大值';
_LOC_CALC_PERCENTAGE = '百分比';

_LOC_SETASSECTION = '设置为节';
_LOC_SWAPAXIS = '切换坐标轴';
_LOC_TURNTO = '转向...';
_LOC_FORMATCELL = '格式单元格';

_LOC_XAXIS = '（X 轴）'; 
_LOC_YAXIS = '（Y 轴）';
_LOC_ZAXIS = '（Z 轴）';

_LOC_ONXAXIS = '在 X 轴上'; 
_LOC_ONYAXIS = '在 Y 轴上';
_LOC_ONZAXIS = '在 Z 轴上';
_LOC_TOOLTIP = '右键单击以编辑或分析这些结果';
