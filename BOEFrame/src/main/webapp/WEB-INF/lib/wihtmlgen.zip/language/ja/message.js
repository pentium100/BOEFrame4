


_LOC_UNKNOWN_DRILLACTION = 'ドリル操作が不明です。';
_LOC_DRILL_NOT_ENABLE = 'ドリル操作は実行できません。';
_LOC_BROWSER_NOT_SUPPORTED = "not localize";

_LOC_OR = ' または';
_LOC_AND = ' および';

_LOC_NEWQUERY = ' (新規クエリー)';

_LOC_DRILLDOWNTO = 'ドリル ダウンのレベル :';
_LOC_DRILLDOWN = 'ドリル ダウン';
_LOC_DRILLUPTO = 'ドリル アップのレベル :';
_LOC_DRILLUP = 'ドリル アップ';
_LOC_DRILLBY = 'ドリル要素';

_LOC_SORT = '並べ替え';
_LOC_SORTDEFAULT = 'デフォルト';
_LOC_SORTASCENDING = '昇順並べ替え';
_LOC_SORTDESCENDING = '降順並べ替え';

_LOC_SORT_ITEM = '並べ替え';
_LOC_FILTERBY_PPP_ITEM = '適用フィルタ ...';
_LOC_SEPARATOR_HIERARCHYNAME = ' -';

_LOC_ADD ='追加'; 
_LOC_REPLACE = '置換';
_LOC_REMOVE = '削除';
_LOC_CALCULATIONS = '計算';
_LOC_CALC_ATTHEBOTTOM = '下に';
_LOC_CALC_ATTHERIGHT = '右に';
_LOC_CALC_SUM = '合計';
_LOC_CALC_COUNT = '件数';
_LOC_CALC_AVERAGE = '平均'; 
_LOC_CALC_MIN = '最小';
_LOC_CALC_MAX = '最大';
_LOC_CALC_PERCENTAGE = 'パーセンテージ';

_LOC_SETASSECTION = 'セクションとして設定';
_LOC_SWAPAXIS = '軸の交換';
_LOC_TURNTO = '変換...';
_LOC_FORMATCELL = 'セルの書式設定';

_LOC_XAXIS = '(X 軸)'; 
_LOC_YAXIS = '(Y 軸)';
_LOC_ZAXIS = '(Z 軸)';

_LOC_ONXAXIS = 'X 軸上'; 
_LOC_ONYAXIS = 'Y 軸上';
_LOC_ONZAXIS = 'Z 軸上';
_LOC_TOOLTIP = '右クリックしてこれらの結果を編集または分析';
