


_LOC_UNKNOWN_DRILLACTION = 'Action d\'exploration inconnue.';
_LOC_DRILL_NOT_ENABLE = 'L\'exploration est impossible.';
_LOC_BROWSER_NOT_SUPPORTED = "not localize";

_LOC_OR = ' ou';
_LOC_AND = ' et';

_LOC_NEWQUERY = ' (Nouvelle requête)';

_LOC_DRILLDOWNTO = 'Exploration avant vers';
_LOC_DRILLDOWN = 'Exploration avant';
_LOC_DRILLUPTO = 'Exploration arrière vers';
_LOC_DRILLUP = 'Exploration arrière';
_LOC_DRILLBY = 'Explorer par';

_LOC_SORT = 'Trier';
_LOC_SORTDEFAULT = 'Par défaut';
_LOC_SORTASCENDING = 'Croissant';
_LOC_SORTDESCENDING = 'Décroissant';

_LOC_SORT_ITEM = 'Trier';
_LOC_FILTERBY_PPP_ITEM = 'Filtrer par...';
_LOC_SEPARATOR_HIERARCHYNAME = ' -';

_LOC_ADD ='Ajouter'; 
_LOC_REPLACE = 'Remplacer';
_LOC_REMOVE = 'Supprimer';
_LOC_CALCULATIONS = 'Calculs';
_LOC_CALC_ATTHEBOTTOM = 'En bas';
_LOC_CALC_ATTHERIGHT = 'A droite';
_LOC_CALC_SUM = 'Somme';
_LOC_CALC_COUNT = 'Nombre';
_LOC_CALC_AVERAGE = 'Moyenne'; 
_LOC_CALC_MIN = 'Min';
_LOC_CALC_MAX = 'Max';
_LOC_CALC_PERCENTAGE = 'Pourcentage';

_LOC_SETASSECTION = 'Définir comme section';
_LOC_SWAPAXIS = 'Inverser les axes';
_LOC_TURNTO = 'Transformer en...';
_LOC_FORMATCELL = 'Format de cellule';

_LOC_XAXIS = '(Axe X)'; 
_LOC_YAXIS = '(Axe Y)';
_LOC_ZAXIS = '(Axe Z)';

_LOC_ONXAXIS = 'Axe X'; 
_LOC_ONYAXIS = 'Axe Y';
_LOC_ONZAXIS = 'Axe Z';
_LOC_TOOLTIP = 'Clic droit pour modifier ou analyser les résultats';
