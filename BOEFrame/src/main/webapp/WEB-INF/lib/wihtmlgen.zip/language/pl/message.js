


_LOC_UNKNOWN_DRILLACTION = 'Nieznana czynność drążenia danych.';
_LOC_DRILL_NOT_ENABLE = 'Drążenie danych nie jest możliwe.';
_LOC_BROWSER_NOT_SUPPORTED = "not localize";

_LOC_OR = ' lub ';
_LOC_AND = ' i ';

_LOC_NEWQUERY = ' (Nowe zapytanie)';

_LOC_DRILLDOWNTO = 'Drążenie danych do ';
_LOC_DRILLDOWN = 'Drążenie ';
_LOC_DRILLUPTO = 'Agregowanie do ';
_LOC_DRILLUP = 'Agregowanie ';
_LOC_DRILLBY = 'Drążenie danych ';

_LOC_SORT = 'Sortuj ';
_LOC_SORTDEFAULT = 'Domyślnie ';
_LOC_SORTASCENDING = 'Rosnąco';
_LOC_SORTDESCENDING = 'Malejąco';

_LOC_SORT_ITEM = 'Sortuj ';
_LOC_FILTERBY_PPP_ITEM = 'Filtruj według...';
_LOC_SEPARATOR_HIERARCHYNAME = ' - ';

_LOC_ADD ='Dodaj'; 
_LOC_REPLACE = 'Replace';
_LOC_REMOVE = 'Usuń';
_LOC_CALCULATIONS = 'Obliczenia';
_LOC_CALC_ATTHEBOTTOM = 'Na dole';
_LOC_CALC_ATTHERIGHT = 'Z prawej';
_LOC_CALC_SUM = 'Suma';
_LOC_CALC_COUNT = 'Liczba';
_LOC_CALC_AVERAGE = 'Średnia'; 
_LOC_CALC_MIN = 'Minimum';
_LOC_CALC_MAX = 'Maksimum';
_LOC_CALC_PERCENTAGE = 'Procent';

_LOC_SETASSECTION = 'Ustaw jako sekcję';
_LOC_SWAPAXIS = 'Zamień osie';
_LOC_TURNTO = 'Zamień na...';
_LOC_FORMATCELL = 'Formatuj komórkę';

_LOC_XAXIS = '(oś X)'; 
_LOC_YAXIS = '(oś Y)';
_LOC_ZAXIS = '(oś Z)';

_LOC_ONXAXIS = 'na osi X'; 
_LOC_ONYAXIS = 'na osi Y';
_LOC_ONZAXIS = 'na osi Z';
_LOC_TOOLTIP = 'Kliknij prawym przyciskiem myszy, aby edytować lub analizować te wyniki';
