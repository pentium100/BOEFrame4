


_LOC_UNKNOWN_DRILLACTION = 'Operazione di drill sconosciuta.';
_LOC_DRILL_NOT_ENABLE = 'Non è possibile eseguire il drill.';
_LOC_BROWSER_NOT_SUPPORTED = "not localize";

_LOC_OR = ' OR';
_LOC_AND = ' AND';

_LOC_NEWQUERY = ' (nuova query)';

_LOC_DRILLDOWNTO = 'Drill down verso ';
_LOC_DRILLDOWN = 'Drill down';
_LOC_DRILLUPTO = 'Drill up verso ';
_LOC_DRILLUP = 'Drill up';
_LOC_DRILLBY = 'Drill per';

_LOC_SORT = 'Ordinamento';
_LOC_SORTDEFAULT = 'Predefinito';
_LOC_SORTASCENDING = 'Crescente';
_LOC_SORTDESCENDING = 'Decrescente';

_LOC_SORT_ITEM = 'Ordinamento';
_LOC_FILTERBY_PPP_ITEM = 'Filtra per...';
_LOC_SEPARATOR_HIERARCHYNAME = ' -';

_LOC_ADD ='Aggiungi'; 
_LOC_REPLACE = 'Sostituisci';
_LOC_REMOVE = 'Rimuovi';
_LOC_CALCULATIONS = 'Calcoli';
_LOC_CALC_ATTHEBOTTOM = 'In basso';
_LOC_CALC_ATTHERIGHT = 'A destra';
_LOC_CALC_SUM = 'Somma';
_LOC_CALC_COUNT = 'Conteggio';
_LOC_CALC_AVERAGE = 'Media'; 
_LOC_CALC_MIN = 'Min';
_LOC_CALC_MAX = 'Max';
_LOC_CALC_PERCENTAGE = 'Percentuale';

_LOC_SETASSECTION = 'Imposta come sezione';
_LOC_SWAPAXIS = 'Inverti assi';
_LOC_TURNTO = 'Trasforma in...';
_LOC_FORMATCELL = 'Formato cella';

_LOC_XAXIS = '(asse X)'; 
_LOC_YAXIS = '(asse Y)';
_LOC_ZAXIS = '(asse Z)';

_LOC_ONXAXIS = 'sull\'asse X'; 
_LOC_ONYAXIS = 'sull\'asse Y';
_LOC_ONZAXIS = 'sull\'asse Z';
_LOC_TOOLTIP = 'Fare clic con il pulsante destro del mouse per modificare o analizzare questi risultati.';
