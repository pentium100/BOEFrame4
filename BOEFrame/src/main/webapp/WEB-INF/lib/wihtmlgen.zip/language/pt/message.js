


_LOC_UNKNOWN_DRILLACTION = 'Ação de Drill desconhecida.';
_LOC_DRILL_NOT_ENABLE = 'A ação do Drill não é possível.';
_LOC_BROWSER_NOT_SUPPORTED = "not localize";

_LOC_OR = ' ou';
_LOC_AND = ' e';

_LOC_NEWQUERY = ' (Nova consulta)';

_LOC_DRILLDOWNTO = 'Drill Down até';
_LOC_DRILLDOWN = 'Drill Down';
_LOC_DRILLUPTO = 'Drill Up até';
_LOC_DRILLUP = 'Drill Up';
_LOC_DRILLBY = 'Drill By';

_LOC_SORT = 'Classificação';
_LOC_SORTDEFAULT = 'Padrão';
_LOC_SORTASCENDING = 'Crescente';
_LOC_SORTDESCENDING = 'Decrescente';

_LOC_SORT_ITEM = 'Classificação';
_LOC_FILTERBY_PPP_ITEM = 'Filtrar por...';
_LOC_SEPARATOR_HIERARCHYNAME = ' -';

_LOC_ADD ='Adicionar'; 
_LOC_REPLACE = 'Substituir';
_LOC_REMOVE = 'Remover';
_LOC_CALCULATIONS = 'Cálculos';
_LOC_CALC_ATTHEBOTTOM = 'Na parte inferior';
_LOC_CALC_ATTHERIGHT = 'À direita';
_LOC_CALC_SUM = 'Soma';
_LOC_CALC_COUNT = 'Contagem';
_LOC_CALC_AVERAGE = 'Média'; 
_LOC_CALC_MIN = 'Mín';
_LOC_CALC_MAX = 'Máx';
_LOC_CALC_PERCENTAGE = 'Porcentagem';

_LOC_SETASSECTION = 'Definir como seção';
_LOC_SWAPAXIS = 'Inverter os eixos';
_LOC_TURNTO = 'Converter em...';
_LOC_FORMATCELL = 'Formatar célula';

_LOC_XAXIS = '(Eixo X)'; 
_LOC_YAXIS = '(Eixo Y)';
_LOC_ZAXIS = '(Eixo Z)';

_LOC_ONXAXIS = 'no Eixo X'; 
_LOC_ONYAXIS = 'no Eixo Y';
_LOC_ONZAXIS = 'no Eixo Z';
_LOC_TOOLTIP = 'Clique com o botão direito do mouse para editar ou analisar os resultados';
